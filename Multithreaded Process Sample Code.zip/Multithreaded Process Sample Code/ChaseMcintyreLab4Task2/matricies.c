/**
* Name: Chase Mcintyre
* Lab/task: Lab 4 Task 2
* Date: 02/15/2018
**/


//Lab 4 task 2 notes
/* multiplying matrixes is figured out
	Each thread computes a value for an index (i,j) of the resulting matrix.
	As a parameter to the thread you should pass a pointer to the following structure
	struct v { int i; int j; };
	Matrix A domain = M, K
	Matrix B domain = K, N
	Matrix AxB domain = M, N

	Sequence of Events: Load matricies in, multiply them using threads, display the
	results
	*/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h> 
#include <sys/wait.h> 
#define MAX_SIZE 1024

int a[MAX_SIZE][MAX_SIZE], b[MAX_SIZE][MAX_SIZE], c[MAX_SIZE][MAX_SIZE];
int m, k, n;

struct v { int i; int j; };



void *matrixThread(void *cellIndex);
void loadMatrices(char *fileName);
void loadMatrix(FILE *file, int m[][MAX_SIZE], int numRows, int numColumns);
void multiply(int a[][MAX_SIZE], int b[][MAX_SIZE], int c[][MAX_SIZE], int m, int k, int n);
void displayMatrix(int m[][MAX_SIZE], int numRows, int numColumns);

int main(int argc, char *argv[])   
{
	
	// (i = row from first matrix, j = column from second matrix)
	//load matricies in
		//to do this we need to read the file input
	// Matrix A = [M][K], Matrix B = [K][N], Matrix C = [M][N] 
	// First line of input gives MKN, the next M lines are the rows of A
	// The next K lines after those are the rows of B
	// The program should check for MKN > 0, check for EOF to ensure user entered correct input
	// General code structure: In main load the matricies (read the input file)
		// Inside of loadMatricies, load A and B using the loadMatrix, one call for each
		// Read the input file in loadMatricies, pass the data gathered to loadMatrix
	// Next, In main display the newly filled matricies A and B(displayMatrix), then call multiply()
		// Multiply creates MxN threads, which each run matrixThread() (create a struct that holds the information (struct v))
		// Store results inside the global array C at index ij


	//First thing to do is to call loadMatricies, with the fileName of the input file
	char *fileName = "input.txt";
	loadMatrices(fileName);
	//printf("back in main\n");
	//Matricies have been filled, the next step is to display the matricies
		//displayMatrix() needs an [][] to display, and the numRows/numColumns
	printf("MATRIX A\n");
	displayMatrix(a, m, k);
	printf("\n");

	printf("MATRIX B\n");
	displayMatrix(b, k, n);
	printf("\n");
	//Matricies have been displayed, next step is to call multiply
		//Multiply needs 2 [][]'s to multiply, an [][] to store results in, and mkn
		//We have access to all of this, so function may be called
	multiply(a, b, c, m, k, n);
	printf("MATRIX A x B\n");
	displayMatrix(c, m, n);


	return 0;
}  

void loadMatrices(char *fileName)
{
	// the loadMatrix function needs the file, number of rows, and columns
		// this means that we need to open and read the first line of the input file
	// 1) Open the file
	FILE *file = fopen(fileName,"r");
	if (file == NULL)
	{
		printf("Error unable to open file");
		exit(0);
	}
	// 2) Read from the file
	fscanf( file, "%d", &m);
	fscanf( file, "%d", &k);
	fscanf( file, "%d", &n);
	//printf("Test %d %d %d\n", m, k, n);
	//We now have access to all the parameters that loadMatrix needs
		//So, lets call loadMatrix and get A&B filled
	loadMatrix(file, a, m, k);
	loadMatrix(file, b, k, n);
	//Reaching this point means that we have sucessfully filled arrays A and B
	//The functionality of this method has been completed, so it will now exit and return to main
}

void loadMatrix(FILE *file, int m[][MAX_SIZE], int numRows, int numColumns)
{
	//we need to use the file to read in numRows rows of numColumns columns
		//to do this we will need to use a nested for loop

	for (int i = 0; i < numRows; i++)
	{
		//this loop will count the number of columns that have been filled
		for (int j = 0; j < numColumns; j++)
		{
			//this loop will count the number of items in each row that have been filled
			//we need to get the next item and put it into array m at index [i][j]
			fscanf(file, "%d", &m[i][j]);
			//printf("read %d into m[%d][%d]\n", m[i][j], i, j);
		}
	}
}

void displayMatrix(int m[][MAX_SIZE], int numRows, int numColumns)
{
	//need to use a nested loop to display the matricies
	for (int i = 0; i < numRows; i++)
	{
		//this loop will run through the first array [i][]
		for (int j = 0; j < numColumns; j++)
		{
			//this loop will run through the second array aspect [][j]
			printf("%d ", m[i][j]);
		}
		printf("\n");
	}
}

void multiply(int a[][MAX_SIZE], int b[][MAX_SIZE], int c[][MAX_SIZE], int m, int k, int n)
{
	// Multiply creates MxN threads, which each run matrixThread() (create a struct that holds 
	//the information (struct v))
		// Store results inside the global array C at index ij

	// for thread creation, the third parameter will be a reference to matrixThread
	// and the fourth parameter will be a reference to void *struct v

	//instantiate variables needed for thread creation
	//printf("test - in Multiply\n");
	pthread_t tid;//[m*n];
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
	int structNumber = 0;
	struct v voidPointer;
	struct v tempStructArray[m*n];
	//create MxN threads
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{

			//create a unique struct
			tempStructArray[structNumber].i = i;
			tempStructArray[structNumber].j = j;


			
			//create the struct v
			voidPointer.i = i;
			voidPointer.j = j;
			//tempStruct.i = i;
			//tempStruct.j = j;

			//Structs have been sucessfully created
			//To call pthread_create I need a tid, attr, function/purpose, and something else
			
			//printf("test - creating thread for c[%d][%d]\n", i, j);
			pthread_create(&tid, &attr, matrixThread,  (void *) &tempStructArray[structNumber]);
			structNumber++;
			usleep(0);
		}
	}
}

void *matrixThread(void *cellIndex)
{
	struct v *testStruct = (struct v*)(cellIndex);
	// int test = testStruct->i;
	// int test2 = testStruct->j;
	//printf("test in matrixThread at %d,%d\n", testStruct->i, testStruct->j);

	//I am sucessfully creating threads and passing them into this method
	//Now I need to do the actual multiplication
	//I've been passed an I and J 
	//I represents the values from the row of A, J represents the values from the column of B
	//I need to multiple A[i][0,1,...,k] by B[0,1,...,k][j], and store the result in C[i][j]

	int rcTotal = 0;
	for (int x = 0; x <= k; x++)
	{
		rcTotal += a[testStruct->i][x] * b[x][testStruct->j];
	}
	c[testStruct->i][testStruct->j] = rcTotal;
	//printf("test in matrixThread - calculated total for r%dc%d is %d\n", 
			//testStruct->i, testStruct->j, rcTotal);
}

// rc = pthread_create(&tid, &attr, thread_do_nothing, NULL);
// 		if (rc) 
// 		{              
// 			printf("ERROR; return code from pthread_create() is %d\n", rc);
// 			exit(-1);
// 		}

