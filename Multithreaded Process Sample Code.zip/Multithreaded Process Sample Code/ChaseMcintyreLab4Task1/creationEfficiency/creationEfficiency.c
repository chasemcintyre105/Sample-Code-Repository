/**
* Name: Chase Mcintyre
* Lab/task: Lab 4 Task 1
* Date: 02/13/2018
**/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h> 
#include <sys/wait.h> 

#define NTHREADS 10
#define NFORKS 10

void fork_do_nothing() 
{
	int i;
	i= 0;
}
void *thread_do_nothing(void *null) 
{
	int i;
	i=0;
	pthread_exit(NULL);
}  


int forkTimeTest() 
{
	int pid, j, status;
	time_t timeStart;
	time_t timeEnd;
	struct timeval tv1;
	struct timeval tv2;

	gettimeofday(&tv1, NULL);
	timeStart = tv1.tv_usec;
	printf("Start time for forkCreationTest: %ld\n", timeStart);
	
	for (j=0; j<NFORKS; j++) 
	{
		
		/*** error handling ***/
		if ((pid = fork()) < 0 )
		{
			printf ("fork failed with error code= %d\n", pid);
			exit(0);
		}
		
		/*** this is the child of the fork ***/
		else if (pid ==0) 
		{
			fork_do_nothing();
			exit(0);
		}
		
		/*** this is the parent of the fork ***/
		else 
		{
			waitpid(pid, &status, 0);
		}
	}
	gettimeofday(&tv2, NULL);
	timeEnd = tv2.tv_usec;
	printf("End time for forkCreationTest: %ld\n", timeEnd);
	long timeElapsed = (tv2.tv_usec + 1000000 * tv2.tv_sec) - (tv1.tv_usec + tv1.tv_sec * 1000000);
	printf("Total time elapsed for forkCreationTest: %ld\n", timeElapsed);
	printf("Average time per fork: %ld\n", (timeElapsed/NFORKS) );
	return timeElapsed;
}

int threadTimeTest(double forkTime) 
{
	int rc, j;
	pthread_t tid;
	pthread_attr_t attr;
	
	time_t timeStart;
	time_t timeEnd;
	struct timeval tv1;
	struct timeval tv2;
	double ratio;

	
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
	
	gettimeofday(&tv1, NULL);
	timeStart = tv1.tv_usec;
	printf("Start time for threadCreationTest: %ld\n", timeStart);
			
	for (j=0; j<NTHREADS; j++) 
	{
		rc = pthread_create(&tid, &attr, thread_do_nothing, NULL);
		if (rc) 
		{              
			printf("ERROR; return code from pthread_create() is %d\n", rc);
			exit(-1);
		}
		
		/* Wait for the thread */
		//rc = pthread_join(tid, NULL);
		// if (rc) {
		// 	printf("ERROR; return code from pthread_join() is %d\n", rc);
		// 	exit(-1);
		// }
	}
	
	gettimeofday(&tv2, NULL);
	timeEnd = tv2.tv_usec;
	printf("End time for threadCreationTest: %ld\n", timeEnd);
	long timeElapsed = (tv2.tv_usec + 1000000 * tv2.tv_sec) - (tv1.tv_usec + tv1.tv_sec * 1000000);	
	printf("Total time elapsed for threadCreationTest: %ld\n", timeElapsed);
	printf("Average time per thread: %ld\n", (timeElapsed/NTHREADS) );
	ratio = (double) timeElapsed;
	ratio = forkTime/ratio;
	printf("Ratio of (fork creation time)/(thread creation time) is %lf\n", ratio);

	pthread_attr_destroy(&attr);
	pthread_exit(NULL);
}

int main(int argc, char *argv[])   
{
	printf("Running forkTest and threadTest to test for Time Efficiency\n");
	double forkTime;
	forkTime = (double) forkTimeTest();
	threadTimeTest(forkTime);
	return 0;
}  

// Performance of threads vs forks - While threads share the same application and memory space, a fork needs its own independent copys and any changes it makes
// This copying is the primary reason why an empty for is slower than a thread.