/**
* Name: Chase Mcintyre
* Lab/task: Lab 4 Task 3
* Date: 02/17/2018
**/


#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h> 
#include <sys/wait.h> 

int **a, **b, **c;
int m, k, n;

struct v { int i; int j; };

void *matrixThread(void *cellIndices);
void allocateAndLoadMatrices(char *fileName);
int** loadMatrix(FILE *file, int **x, int numRows, int numColumns);
void multiply(int **a, int **b, int **c, int m, int k, int n);
void displayMatrix(int **x, int numRows, int numColumns);

int main(int argc, char *argv[])   
{
	//printf("test - in main\n");
	//The first step is to call allocateAndLoadMatrices 
	char *fileName = "input.txt";
	allocateAndLoadMatrices(fileName);


	//Reaching this point means that we have sucessfully allocated and loaded the matricies
	//printf("test - Back in main - displaying matricies\n");
	//the next step is to display matrix a and b
	printf("Matrix A\n");
	displayMatrix(a, m, k);
	printf("\n");
	printf("Matrix B\n");
	displayMatrix(b, k, n);	
	printf("\n");


	//Matricies have been displayed, next step is to call multiply
	multiply( a, b, c, m, k, n );

	//multiplication is done, display matrix c
	printf("Matrix C\n");
	displayMatrix(c, m, n);
}

void allocateAndLoadMatrices(char *fileName)
{
	//printf("test - in allocateAndLoadMatrices\n");
	//now I need to dynamically allocate the arrays
	//I need to not only fill them, but I need to malloc size for them as well
	//I know how much size I need to malloc based off of the first line of the input
	//So, lets read from the input file
	FILE *file = fopen(fileName,"r");
	if (file == NULL)
	{
		printf("Error unable to open file");
		exit(0);
	}
	// 2) Read from the file
	fscanf( file, "%d", &m);
	fscanf( file, "%d", &k);
	fscanf( file, "%d", &n);
	//printf("Test m=%d k=%d n=%d\n", m, k, n);
	
	//We now have access to all the information that we need to call loadMatrix
	// When I do call it, I'll know how much space to malloc based off of M,K,N.
	//reference link: https://stackoverflow.com/questions/4993076/char-and-dereferencing-pointers
	a = loadMatrix( file, a, m, k );
	//printf("matrix A has been loaded\n");
	//printf("test - accessing array A at [0][0] = %d\n", a[0][0] );
	b = loadMatrix( file, b, k, n );
	//printf("matrix B has been loaded\n");
	//printf("test - accessing array A at [0][0] = %d\n", a[0][0] );

	//lastly, we need to malloc proper room for matrix c
	//first, malloc the main column
	c = malloc(sizeof*c * m);
	//next, malloc each row
	for(int i = 0; i < n; i++)
	{
		c[i] = malloc(sizeof**c * n);
	}

	//Reaching this point means that we have sucessfully filled arrays A and B
	//The functionality of this method has been completed, so it will now exit and return to main

}

int** loadMatrix(FILE *file, int **x, int numRows, int numColumns)
{
	//printf("test - in loadMatrix\n");
	//int **tempPointer = *x;
	//testFunction(*m); this is functional, *m is type int**
	//apparently, & will add a layer of pointers, and * removes a pointer layer
	//This makes sense, since & will give us the address of the pointer which itself contains an address
	//Whereas * will give us what m is pointing to, which is another pointer, but one closer to the actual value
	
	//Now we need to malloc and fill the array
	//this will be a nested loop, like task2

	//firstly I need to malloc the main column
	x = malloc(sizeof*x * numRows);

	for (int i = 0; i < numRows; i++)
	{
		//now I need to malloc each row of the column
		x[i] = malloc(sizeof**x * numColumns);

		for (int j = 0; j < numColumns; j++)
		{
			//now I need to fill each item of the row
			fscanf( file, "%d", &x[i][j] );
			//printf("test - just read value %d into x[%d][%d]\n", x[i][j], i, j);
		}
	}
	//printf("test - accessing array at [0][0] = %d\n", x[0][0]);
	return x;
}

void displayMatrix(int **x, int numRows, int numColumns)
{
	//printf("test in displayMatrix\n");
	//need to use a nested loop
	//outer loop will go through row by row
	for(int i = 0; i < numRows; i++)
	{
		//inner loop should go through each row, column by column
		for (int j = 0; j < numColumns; j++)
		{
			//printf("test - in displayMatrix, printing x[%d][%d]\n", i, j);
			//here we need to reference the item
			printf("%d ", x[i][j]);
		}
		printf("\n");
	}
}

void multiply(int **a, int **b, int **c, int m, int k, int n)
{
	// Multiply creates MxN threads, which each run matrixThread() (create a struct that holds 
	//the information (struct v))
		// Store results inside the global array C at index ij

	//instantiate variables needed for thread creation
	//printf("test - in Multiply\n");
	pthread_t tid;//[m*n];
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
	int structNumber = 0;
	struct v tempStructArray[m*n];
	//create MxN threads
	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			//create a unique struct
			tempStructArray[structNumber].i = i;
			tempStructArray[structNumber].j = j;

			//Struct has been sucessfully created
			//now I need to call pthread_create
			
			//printf("test - creating thread for c[%d][%d]\n", i, j);
			pthread_create(&tid, &attr, matrixThread, (void *) &tempStructArray[structNumber]);
			structNumber++;
			usleep(0);
		}
	}
}

void *matrixThread(void *cellIndices)
{
	//derefence the struct 
	struct v *testStruct = (struct v*)(cellIndices);

	//do the multiplication
	int rcTotal = 0;
	for (int x = 0; x < k; x++)
	{
		rcTotal += a[testStruct->i][x] * b[x][testStruct->j];
	}
	c[testStruct->i][testStruct->j] = rcTotal;

}


