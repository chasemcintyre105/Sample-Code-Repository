/**
* Name: Chase Mcintyre
* Lab/task: Lab 4 Task 4
* Date: 02/18/2018
**/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h> 
#include <sys/wait.h> 


void *matrixThread(void *matrixCell);
void allocateAndLoadMatrices(char *fileName, int ***a, int ***b, int ***c, int *m, int *k, int *n);
int **loadMatrix(FILE *file, int **x, int numRows, int numCols);
pthread_t **multiply(int **a, int**b, int**c, int m, int k, int n);
void displayMatrix(int **x, int numRows, int numColumns);

//new functions
pthread_t **alloc_tids(int numRows, int numColumns);
void free_tids(pthread_t **threads, int numRows);
//how should these be used? alloc_tids returns  **pthread_t, so I should use this in 
//	the thread creation process? but how so exactly?
//This program is supposed to allow the user to multiply any # of pairs of matricies concurrently
//	so, should I use this method to create all necesarry threads for a multiplication?
//given that the only parameters are numRows/numColumns I'm not sure what else this method could do
//this method seems to serve the function of creating a properly sized pthead_t matrix without
//	the use of any global variables
//free_tids is self evident

struct matrixCell
{
    int i;
    int j;
    int k;
    int **a;
    int **b;
    int **c;
};

//What is the function of this new struct? it contains an i and j (assumably for a nested loop)
//all 3 matricies, and k, the shared length of matrix A and B
//what is loop one would want to run with the I and J?
//the method that uses this is matrixThread
//the i and j must be the c[i][j] that the thread will compute
//normally this would be done by a struct v but, given the lack of global variables,
//we need a new struct that constains the information we can no longer access globally
//we need the k to know where to stop the loop in the matrixThread() method
//we need access to the arrays so we can get values, and fill values



int main(int argc, char *argv[])
{   
   	int **a, **b, **c; // matrices
   	int m, k, n; // dimensions of the matrices m x k and k x n

	// process argument list
	allocateAndLoadMatrices(argv[1], &a, &b, &c, &m, &k, &n);
	//printf("Test - m=%d  k=%d  n=%d\n", m, k, n);
	//printf("test in allocateAndLoadMatrices - accessing a at [0][0]=%d\n", a[0][0]);
	//printf("test in allocateAndLoadMatrices - accessing b at [0][0]=%d\n", b[0][0]);

	//matrix A and B are loaded in, now I'll allocate space for matrix c
	//first, malloc the main column
	c = malloc(sizeof*c * m);
	//next, malloc each row
	for(int i = 0; i < n; i++)
	{
		c[i] = malloc(sizeof**c * n);
	}

	//Reaching this point means that matrix C has been loaded in
	//the next step is to display the existing matricies
	printf("Matrix A\n");
	displayMatrix(a, m, k);
	printf("\n");
	printf("Matrix B\n");
	displayMatrix(b, k, n);	
	printf("\n");

	//the matricies have been sucessfully displayed
	//the next step is to call multiply?
	//multiply returns pthread_t **, so maybe it should be structred like 
	// free_tids( multiply(...), m )?
	free_tids( multiply(a, b, c, m, k, n), m );

	//reaching this point means that we have filled matrix C, and freed the malloc'd tid's
	//the last step is to display matrix C
	printf("Matrix C\n");
	displayMatrix( c, m, n);


}

void allocateAndLoadMatrices(char *fileName, int ***a, int ***b, int ***c, int *m, int *k, int *n)
{
	//printf("test - in allocateAndLoadMatrices\n");
	FILE *file = fopen(fileName,"r");
	if (file == NULL)
	{
		printf("Error unable to open file");
		exit(0);
	}

	//now I need to read from the file to get my m, k, n
	fscanf( file, "%d", m);
	fscanf( file, "%d", k);
	fscanf( file, "%d", n);
	//successfully read in, now I need to load the matricies in
	*a = loadMatrix(file, *a, *m, *k);
	//printf("test in allocateAndLoadMatrices - accessing a at [0][0]=%d\n", *a[0][0]);
	*b = loadMatrix(file, *b, *k, *n);
	//printf("test in allocateAndLoadMatrices - accessing b at [0][0]=%d\n", *b[0][0]);


}

int** loadMatrix(FILE *file, int **x, int numRows, int numColumns)
{
	//printf("test - in loadMatrix\n");
	//I need to load the matrix in
	//the first step is to malloc appropriatly for the passed array
	//firstly, malloc the main column
	x = malloc(sizeof*x * numRows);

	//next I need to malloc the rows
	for (int i = 0; i < numRows; i++)
	{
		x[i] = malloc(sizeof**x * numColumns);
		for (int j = 0; j < numColumns; j++)
		{
			//now I need to fill each item of the row
			fscanf( file, "%d", &x[i][j] );
			//printf("test - just read value %d into x[%d][%d]\n", x[i][j], i, j);
		}
	}
	//printf("test - accessing array at [0][0] = %d\n", x[0][0]);
	return x;

}

void displayMatrix(int **x, int numRows, int numColumns)
{
	//we need to use a nested loop

	for(int i = 0; i < numRows; i++)
	{
		//this outer loop will go through the main column, row by row
		for(int j = 0; j < numColumns; j++)
		{
			//this inner loop will print out each element of the current row
			printf("%d ", x[i][j]);
		}
		printf("\n");
	}
}

pthread_t **multiply(int **a, int**b, int**c, int m, int k, int n)
{
	//multiply should function just as it does in the previous sections, apart from 
	//		several small differences
	//this version of mutiply should make use of the new function alloc_tids,
	// it should return the **pthread_t, such that free_tid's can function,
	// it should utilize the new struct matrixCell instead of struct v
	/* TO USE:
			alloc_tids
			return **pthread_t
			matrixCell
			*/
	//the first step is to allocate and create a **pthread_t of proper size by utilizing
	//the new function. numRows should me m, numColumns should be n
	pthread_t **tidMatrix = alloc_tids( m, n );

	//we now have access to a matrix of unique, malloc'd tid's
	/* TO USE:
			return **pthread_t
			matrixCell
			*/
	//the next step should be to instantiate the pthread_t_attr
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
	
	//attr instantiated, now we need to create the struct matrixCells that will be passed
	//to the matrixThread function. We will need M x N structs
	int structNumber = 0;
	struct matrixCell structArray[m*n];

	//the structs have been created, the threads have been created, the attr has been created
	//now we need to call matrixThread, with the appropriate information put into
	//the structs. this could be done in a nested loop, as in previous tasks
	for(int i = 0; i < m; i++)
	{
		//this outer loop will go through tidMatrix row by row
		for(int j = 0; j < n; j++)
		{
			//this inner loop will address each element
			//firstly, lets get all the correct information loaded into thr struct
			structArray[structNumber].i = i;//the row of matrix A to grab, and row of C to be filled
			structArray[structNumber].j = j;//the column of matrix B to get, and column of C to fill
			structArray[structNumber].k = k;//the shared dimension of A and B, to be used in matrixThread
			structArray[structNumber].a = a;//need to get values from here in sub method
			structArray[structNumber].b = b;//need to get values from here in sub method
			structArray[structNumber].c = c;//need to place results of sub method in here

			//structs have been created and given the proper information
			//Now I need to create the threads 
			pthread_create( &tidMatrix[i][j], &attr, matrixThread,
							(void *) &structArray[structNumber] );

			structNumber++;
			usleep(0);
		}
	}

	//we should now have created all the threads by reference
	/* TO USE:
			return **pthread_t
			*/

	return tidMatrix;
}


pthread_t **alloc_tids(int numRows, int numColumns)
{

	//here I need to create a **pthread_t of size M x N
	//this could be done in a nested loop
	pthread_t **tidMatrix;
	//first things first, I need to malloc the main column of the **pthread_t
	tidMatrix = malloc( sizeof*tidMatrix * numRows );

	//Now I'll use a nested loop. the outer loop will malloc each row, the inner loop will
	//put values into the matrix
	for(int i = 0; i < numRows; i++)
	{
		//this outer loop will malloc each row of the matrix
		tidMatrix[i] = malloc( sizeof**tidMatrix * numColumns);

		for(int j = 0; j < numColumns; j++)
		{
			//this inner loop will create unique tid's and put them into the matrix
			pthread_t tid;
			tidMatrix[i][j] = tid;
		}
	}
	//tidMatrix should be malloc'd and filled with unique tid's now, so we can return it
	//we shouldn't need to create the attribute part of the thread at this point

	return tidMatrix;
}

void *matrixThread(void *matrixCell)
{
	//printf("test - in matrixThread\n");

	//here we need to do the multiplcation for a given index of matrix C
	//the index of C is C[i][j]
	//We will get values from A at row i, and B at column J
	//We will get K values from each struct, multiply, and add to a running total
	//after we have gotten all of these values, the result is to be put into C at the given index

	//first things first, dereference matrixCell
	struct matrixCell *tempStruct = (struct matrixCell*)(matrixCell);

	//next, we need to get the total of the A-Row x B-Column
	int rcTotal = 0;
	for(int x = 0; x < tempStruct->k; x++)
	{
		rcTotal += ( tempStruct->a[tempStruct->i][x] ) * ( tempStruct->b[x][tempStruct->j] );
	}
	//we have the total, now we need need to input it into matrix C
	tempStruct->c[tempStruct->i][tempStruct->j] = rcTotal;
	//we should be done now
}

void free_tids(pthread_t **threads, int numRows)
{
	//we will need to free each pointer

	//first, we will free each row by referencing the main column
	for(int i = 0; i < numRows; i++)
	{
		free(threads[i]);
	}
	//lastly, we need to free the main column
	free(threads);
}


