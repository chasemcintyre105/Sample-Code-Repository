/**
* Name: Chase Mcintyre
* Lab/task: Cilisp task 3
* Date: 10/25/2017
**/
#include "cilisp.h"

int main(void)
{
    yyparse();
    return 0;
}

void yyerror(char *s)
{
    fprintf(stderr, "%s\n", s);
}

// find out which function it is
int resolveFunc(char *func)
{
   char *funcs[] = { "neg", "abs", "exp", "sqrt", "add", "sub", "mult", "div", "remainder", "log", "pow", "max", "min", ""};
   
   int i = 0;
   while (funcs[i][0] !='\0')
   {
      if (!strcmp(funcs[i], func))
         return i;
         
      i++;
   }
   yyerror("invalid function"); // paranoic -- should never happen
   return -1;
}

// create a node for a number
AST_NODE *number(double value)
{
    AST_NODE *p;
    size_t nodeSize;

    // allocate space for the fixed sie and the variable part (union)
    nodeSize = sizeof(AST_NODE) + sizeof(NUMBER_AST_NODE);
    if ((p = malloc(nodeSize)) == NULL)
        yyerror("out of memory");

    p->type = NUM_TYPE;
    p->data.number.value = value;

    return p;
}

// create a node for a function
AST_NODE *function(char *funcName, AST_NODE *op1, AST_NODE *op2)
{
    AST_NODE *p;
    size_t nodeSize;

    // allocate space for the fixed sie and the variable part (union)
    nodeSize = sizeof(AST_NODE) + sizeof(FUNCTION_AST_NODE);
    if ((p = malloc(nodeSize)) == NULL)
        yyerror("out of memory");

    p->type = FUNC_TYPE;
    p->data.function.name = funcName;
    p->data.function.op1 = op1;
    p->data.function.op2 = op2;

    return p;
}

// free a node
void freeNode(AST_NODE *p)
{
    if (!p)
       return;
       
    if (p->type == FUNC_TYPE)
    {
        free(p->data.function.name);
        freeNode(p->data.function.op1);
        freeNode(p->data.function.op2);
    }
        
    free (p);
}

void translate(AST_NODE *p)
{
   if (!p)
   {
      return;
   }
   if (p->type == 1)
   {
      int temp = resolveFunc(p->data.function.name);
      char temp2;
      if (temp == 4 || temp == 5 || temp == 6 || temp == 7)
      {
          printf("( ");
          translate(p->data.function.op1);
          switch (temp)
          {
            case 4: temp2 = '+';
                    break;
            case 5: temp2 = '-';
                    break;
            case 6: temp2 = '*';
                    break;
            case 7: temp2 = '/';
                    break;                                
          }
          printf(" %c ", temp2);
          translate(p->data.function.op2);
          printf(" )");
      }
      else
      {
          printf(" %s ", p->data.function.name);
          printf("( ");
          translate(p->data.function.op1);
          printf(" )");
      }
   }
   if (p->type == 0)
   {
    printf( " %.6lf ", p->data.number.value);
   }

}  

