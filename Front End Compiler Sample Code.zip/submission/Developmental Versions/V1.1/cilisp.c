/**
* Name: Chase Mcintyre
* Lab/task: Cilisp Task 2
* Date: 10/25/2017
**/
#include "cilisp.h"

int main(void)
{
    yyparse();
    return 0;
}

void yyerror(char *s)
{
    fprintf(stderr, "%s\n", s);
}

int resolveFunc(char *func)
{
   char *funcs[] = { "neg", "abs", "exp", "sqrt", "add", "sub", "mult", "div", "remainder", "log", "pow", "max", "min", "exp2", "cbrt", "hypot", ""};
   
   int i = 0;
   while (funcs[i][0] !='\0')
   {
      if (!strcmp(funcs[i], func))
         return i;
         
      i++;
   }
   yyerror("invalid function"); // paranoic -- should never happen
   return -1;
}

double calc(char *func, double op1, double op2)
{

// TBD: implement
   double returnValue = 0.0;
   int funcNum = resolveFunc(func);

   switch (funcNum)
   {
      case 0:
            // if ( op2.dval != NULL )
          // {
          //   yyerror(" Error in abs - op2 is not null")
          // }
          // else
          // {
            returnValue = -( op1 );
          // }
          break;
      case 1:
          // if ( op2.dval != NULL )
          // {
          //   yyerror(" Error in abs - op2 is not null")
          // }
          // else
          // {
            returnValue = fabs( op1 );
          //}
          break;
      case 2: 
          // if ( op2.dval != NULL )
          // {
          //   yyerror(" Error in exp - op2 is not null")
          // }
          // else
          // {
            returnValue = exp( op1 );
          //}
          break;
      case 3:
          // if ( op2.dval != NULL )
          // {
          //   yyerror(" Error in sqrt - op2 is not null")
          // }
          // else
          // {
            returnValue = sqrt( op1 );
          //}
            break;

      case 4:
          // if ( op2.dval == NULL )
          // {
          //   yyerror(" Error in add - op2 is not null")
          // }
          // else
          // {
            returnValue = ( op1 + op2 );
          // }
            break;
      case 5:
          // if ( op2.dval == NULL )
          // {
          //   yyerror(" Error in sub - op2 is not null")
          // }
          // else
          // {
             returnValue = ( op1 - op2 );
          // }
             break;
      case 6:
          // if ( op2.dval == NULL )
          // {
          //   yyerror(" Error in mult - op2 is not null")
          // }
          // else
          // {
             returnValue = ( op1 * op2 );
          // }
             break;
      case 7:
          // if ( op2.dval == NULL )
          // {
          //   yyerror(" Error in div - op2 is not null")
          // }
          // else
          // {
             returnValue = ( op1 / op2 );
          // }
             break;
      case 8:
        // if ( op2.dval == NULL )
        //   {
        //     yyerror(" Error in remainder - op2 is not null")
        //   }
        //   else
        //   {
             returnValue = fmod( op1, op2 );
        //   }
             break;
      case 9:
          // if ( op2.dval != NULL )
          // {
          //   yyerror(" Error in log - op2 is not null")
          // }
          // else
          // {
             if ( op1 == 10 || op1 == 2)
             { 
             returnValue = ( log(op2) / log(op1) );
             }
          // }
             break;
      case 10:
          // if ( op2.dval == NULL )
          // {
          //   yyerror(" Error in pow - op2 is not null")
          // }
          // else
          // {
             returnValue = pow( op1 , op2 );
          // }
             break;
      case 11:
          // if ( op2.dval == NULL )
          // {
          //   yyerror(" Error in max - op2 is not null")
          // }
          // else
          // {
             if ( op1 < op2 )
             {
               returnValue = op2;
             }
             else
             {
               returnValue = op1;
             }
            break;

      case 12:
          // if ( op2.dval == NULL )
          // {
          //   yyerror(" Error in min - op2 is not null")
          // }
          // else
          // {
             if ( op1 < op2 )
             {
               returnValue = op1;
             }
             else
             {
               returnValue = op2;
             }
             break;
           
      case 13:
          returnValue = exp2( op1 );
          break;
      case 14:
          returnValue = cbrt( op1 );
          break;
      case 15:
          returnValue = hypot( op1, op2 );
          break;
      case 16:
          break;            
      default:
          printf("Default reached in calc switch \n");
          break;

        }
        return returnValue;

}  
