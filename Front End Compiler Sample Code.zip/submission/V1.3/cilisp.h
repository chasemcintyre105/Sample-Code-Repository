/**
* Name: Chase Mcintyre
* Lab/task: Cilisp task 10
* Date: 12/04/2017
**/
#ifndef __cilisp_h_
#define __cilisp_h_

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <math.h>

#include "cilisp.tab.h"

int yyparse(void);
int yylex(void);
void yyerror(char *);

typedef enum { NUM_TYPE, FUNC_TYPE, SYM_TYPE, CONDITIONAL_TYPE } AST_NODE_TYPE;
typedef enum { UNDEFINED, INTEGER, REAL, USER } VAR_TYPE;

typedef struct
{
    double value;
} NUMBER_AST_NODE;


typedef struct
{
   char *name;
   struct ast_node *op1;
   struct ast_node *op2;
} FUNCTION_AST_NODE;

typedef struct 
{
   char *name;
   struct ast_node *arg_list;
   double value;
} SYMBOL_AST_NODE;

typedef struct 
{
   char *name;
   struct ast_node *conditionalStatement;
   struct ast_node *conditional1;
   struct ast_node *conditional2;
   
} CONDITIONAL_AST_NODE;

typedef struct ast_node
{
   struct ast_node *parent;
   struct linked_list *scope;
   AST_NODE_TYPE type;
   union
   {
      NUMBER_AST_NODE number;
      FUNCTION_AST_NODE function;
      SYMBOL_AST_NODE symbol;
      CONDITIONAL_AST_NODE conditional;
   } data;
   struct ast_node *nextAST;
   struct ast_node *previous;
} AST_NODE;

typedef struct linked_list
{
   VAR_TYPE type;
   char *name;
   AST_NODE *value;
   AST_NODE *param_list;
   struct linked_list *next;
} LINKED_LIST;


AST_NODE *number(double value);
AST_NODE *link_s_expr(AST_NODE *currentList, AST_NODE *newNode);
AST_NODE *function(char *funcName, AST_NODE *s_expr_list);
AST_NODE *conditional(AST_NODE *conditionalStatement, AST_NODE *conditional1, AST_NODE *conditional2);
AST_NODE *link_linked_list( AST_NODE *func, struct linked_list *list );
AST_NODE *link_to_symbol(char *symbolName, AST_NODE *arg_list);
AST_NODE *link_arg_list(char *symbolName, AST_NODE *arg_list);
AST_NODE *symbol (char *symbol);
LINKED_LIST *let_elem( char *type, char *symbol, AST_NODE *expr );
LINKED_LIST *user_let_elem(char *userFuncName, AST_NODE *arg_list, AST_NODE *s_expr_list);
double evalSymbol(AST_NODE *currentNode, LINKED_LIST *toSearch, char *symbol);
double eval_user_func(AST_NODE *funcCall, LINKED_LIST *userFunc);
AST_NODE *connect(LINKED_LIST *scope, AST_NODE *nameHolder);

void find_and_replace_symbols(AST_NODE *arg_list, AST_NODE *currentNode);
void freeNode(AST_NODE *p);

double eval(AST_NODE *ast);

#endif
