/**
* Name: Chase Mcintyre
* Lab/task: Cilisp task 10
* Date: 12/04/2017
**/
#include "cilisp.h"

int main(void)
{
    yyparse();
    return 0;
}

void yyerror(char *s)
{
    fprintf(stderr, "%s\n", s);
}

// find out which function it is
int resolveFunc(char *func)
{
   char *funcs[] = { "neg", "abs", "exp", "sqrt", "add", "sub", "mult", "div", "remainder", "log", "pow", "max", "min", "exp2", "cbrt", "hypot", "print", "smaller", "equal", "larger", "rand", "read"};
   
   int i = 0;
   while (funcs[i][0] !='\0')
   {
      if (!strcmp(funcs[i], func))
         return i;
         
      i++;
   }
   yyerror("invalid function"); // paranoic -- should never happen
   return -1;
}

// create a node for a number
AST_NODE *number(double value)
{
    AST_NODE *p;
    size_t nodeSize;

    // allocate space for the fixed sie and the variable part (union)
    nodeSize = sizeof(AST_NODE) + sizeof(NUMBER_AST_NODE);
    if ((p = malloc(nodeSize)) == NULL)
        yyerror("out of memory");

    p->type = NUM_TYPE;
    p->data.number.value = value;

    return p;
}

int traverseListForType(char *name, struct linked_list *currentNode)
{
    //We are given the name of a node with a null type, and a scope to check for a node with a type and identical name
    //the null type node needs to inherit this nodes type
    int flag2 = 0;

        //Case handle for a single node scope, or no scope at all, which can be thrown with this declaration
        if (currentNode->next == NULL || currentNode == NULL)
        {
          //if this is the case, return null, and the caller will check the next scope
          return -1;
        }
        //We have nodes in this chain to check
        else
        {
          //Search through the chain starting with currentNode for identical name to inherit type from
          while (flag2 == 0)
          {
            //are the name of our currentNode and the parameter name the same?
            //printf("comparing \"%s\" to \"%s\"\n", name, currentNode->name);
            if (strcmp(name, currentNode->name) == 0)
            {
              //yes they are, return currentNode's type to be assigned to the null node
             //printf("found match\n");
             return currentNode->type;
            }
            else
            {
              //No they arent the same, so lets check the next node
              //Is there another node to check?
              if (currentNode->next == NULL)
              {
                //No there is not, set flag2 to break out of this search
                flag2 = 1;
              }
              else
              {
                //Yes there is, grab the next node and repeat the search
                currentNode = currentNode->next;
              }
            }
          }
          //Reaching this point means that the chain has run out of Nodes to check and a type was not found for our
          //Null type node. We should now return null and let the caller pass the next scope to be checked
          return -1;
        }
}
      

AST_NODE *link_linked_list( AST_NODE *func, struct linked_list *list )
{
  //printf("test - linking func %s with list %s\n", func->data.function.name, list->name);
  //If linking two lists together, and then linking them onto func (embedded list case)
  if( func->scope != NULL)
  {
    struct linked_list *tempList = func->scope;
    while (tempList->next != NULL )
    {
      tempList = tempList->next;
    }
    tempList->next = list;  
    //Two lists joined together

    //check tempList for nodes with null type
    int typeTemp;
    struct linked_list *currentNode = func->scope;
    struct linked_list *currentNode2;
    AST_NODE *currentParent;
    int flag = 0;
    int flag2 = 0;
    int foundType = 0;

    //Checks if the 2 lists we just linked have any nodes with null types, if they do it finds the correct type or errors out.
    while(flag == 0)
    {
      flag2 = 0;
      //printf("checking node %s, type is %d\n", currentNode->name, currentNode->type);
      //Does our current node have a type, or is it NULL?
      if ( currentNode->type == 0 )
      {
        //It is null, start by searching the current scope
        //This doesn't case handle for currentNode->next == NULL, but the subroutine handles for this case
        //printf("calling traverse on (%s, %s) value(%lf)\n", currentNode->name, currentNode->next->name, currentNode->value->data.number.value);
        typeTemp = traverseListForType(currentNode->name, currentNode->next);
        if (typeTemp != 0)
        {
          //printf("assigning new type (%d) to %s", typeTemp, currentNode->name);
          currentNode->type = typeTemp;
        }
      }
      
      //Did the current list have the node type we looked for?
      if (currentNode->type != 0)
      {
        //Type for null node found, do we have more elements in our tempList to check?
        if (currentNode->next == NULL)
        {
          //NO we don't, all elements have types.
          flag = 1;
        }
        else
        {
          //Yes we do, get the next node and check it
          currentNode = currentNode->next;
        }
      }
      //It didn't, time to search the scopes of parent nodes until we find it or run out of parent scopes
      else
      {
        //Do we have any parent nodes to check?
        if (func->parent == NULL)
        {
          //We don't have any parents to check and the current scope doesn't have out type, error out
          printf("ERROR: undefined variable type case 1\n");
          exit(0);
        }
        //We do, lets check them
        else
        {
          currentParent = func->parent;

          while(flag2 == 0)
          {

          //Does the parent node we are looking at have a scope to check?
          while (currentParent->scope == NULL)
          {
            //It doesn't, so lets see if it has a parents itself we can check
            if (currentParent->parent != NULL)
            {
              //The parent node doesn't have a scope but does have another parent to check
              currentParent = currentParent->parent;
            }
            else
            {
              //The parent node doesn't have a scope, and doesn't have another parent. We are out of places to check, error out
              printf("ERROR: undefined variable type case 2 \n");
              exit(0);
            }
          }
          //We have a new Parent node that has a scope, lets check it
          
            //Check parent node's scope
            typeTemp = traverseListForType(currentNode->name, currentParent->scope);
            if (typeTemp != -1)
            {
              currentNode->type = typeTemp;
              flag2 = 1;
            }
            else
            {
              //We didn't, node type still null, we need to check for further parents.
              if (currentParent->parent == NULL)
              {
                //There are no more parents. We are out of places to check, error out
                printf("ERROR: undefined variable type case 3 \n");
                exit(0);
              }
              else
              {
                //There are more parents, get the next one, and restart parent scope checking process
                currentParent = currentParent->parent;
              }
            }
          }
        }
      }
    }
    //Reaching this point means that flag = 1, which only happens after our 2 linked together lists have been fully purged of 
    //Nodes with null type. 
    //We are ready to link the new conjoined list up to the function node
    //func->scope = tempList;
    return func;
  }

  //Reaching this point means that we aren't in an embedded scope case
  //All we need to do is check for variable redefinitons if this is the case
  
  //Link function with the new scope
  func->scope = list;

  char *currentName;
  struct linked_list *currentNode = list;
  struct linked_list *currentNode2;
  int flag = 0;

  //Check each node against all the others in the chain to see if it is a redeclaration
  while ( currentNode->next != NULL )  //While we have more nodes to check
  {
    currentName = currentNode->name;
    flag = 0;
    currentNode2 = currentNode->next;
    //Inner loop that checks currentName against the names of all subsequent nodes in the linked list
    while( flag == 0 )
    {
      //if the names are equal, error our
      if (strcmp(currentName, currentNode2->name) == 0 )
      {
        printf("ERROR: redeclaration of variable <%s> attempted\n", currentName);
        exit(0);
      }
      //if the name are not equal
      else
      {
        //do we have another node in the chain to check?
        if (currentNode2->next != NULL)
        {
          //yes we do, so grab it and repeat the checking process
          currentNode2 = currentNode2->next;
        }
        else
        {
          //no we don't, so set flag to break out of the inner loop
          flag = 1;
        }
      }
    }
    //Reaching this point means that the inner loop has checked the name of our current node against the names of all other nodes
    //and hasn't errord out, so it is a unique node. We are ready to move onto the next node.
    currentNode = currentNode->next;
  }
  //reaching this point means we have checked every node in the chain and none of them are redeclarations.
  return func;
}

AST_NODE *symbol (char *symbol)
{
  AST_NODE *p;
  size_t nodeSize;

  nodeSize = sizeof(AST_NODE);
  if ((p = malloc(nodeSize)) == NULL)
    yyerror( "out of memory" );

  p->type = SYM_TYPE;
  p->data.symbol.name = symbol;
  p->parent = NULL;

  return p;
}

int evalForInt(AST_NODE *expr)
{
  int returnValue = 0;
  double tempDouble;
  //Evaluates an expression checking for any ints
  //Check for numberNode
  if (expr->type == 0)
  {
    //Check if # is an int
    if ( (int) expr->data.number.value == expr->data.number.value )
    {
      //it is an int, return 0
      returnValue = 0;
    }
    else
    {
      //it is a real, return 1. Only one double is needed to force cast as double
      returnValue = 1;
    }
  }
  else if (expr->type == 1)
  {
    //must be function, recursively call for op1 and op2
    if (expr->data.function.op1 != NULL)
    {
      returnValue += evalForInt(expr->data.function.op1);
    }
    if (expr->data.function.op2 != NULL)
    {
      returnValue += evalForInt(expr->data.function.op2);
    }
  }
  else if (expr->type == 2)
  {
    tempDouble = evalSymbol(expr->parent, expr->parent->scope, expr->data.symbol.name);
    if ( (int) tempDouble == tempDouble )
    {
      returnValue = 0;
    }
    else
    {
      returnValue = 1;
    }
  }
  
  return returnValue;
}

LINKED_LIST *let_elem( char *type, char *symbol, AST_NODE *expr )
{
  struct linked_list *p;
  size_t llSize;
  double tempDouble;

  llSize = sizeof(struct linked_list);
  if ((p = malloc(llSize)) == NULL)
    yyerror( "out of memory" );

  p->name = malloc((sizeof(symbol)) * sizeof(char));
  p->name = symbol;

  
  

  AST_NODE *temp;
  size_t nodeSize;
  nodeSize = sizeof(AST_NODE);
  if ((temp = malloc(nodeSize)) == NULL)
    yyerror( "out of memory" );
  p->value = expr;
  p->next = NULL;
  if (type != NULL)
  {
    int intTester;
    if ( strcmp("integer", type) == 0 )
    {
      //Make sure it should be int
      //Do so by evaluating expr to make sure it only involves ints
      //If expr contains any real numbers, the type of this symbol must be coerced to real
      intTester = evalForInt(expr);
      if (intTester == 0)
      {
        p->type = 1;
      }
      else
      {
        printf("WARNING: incompatible type assignment for variable <%s>\n", symbol);
        p->type = 2;
      }
    }
    else if ( strcmp("real", type) == 0 )
    {
      //Make sure it should be double
      //Do so by evaluating expr to see if it involves any ints
      //If expr only contains ints, the type of this symbol must be coerced to int
      intTester = evalForInt(expr);
      if (intTester == 0)
      {
        printf("WARNING: incompatible type assignment for variable <%s>\n", symbol);
        p->type = 1;
      }
      else
      {
        p->type = 2;
      }
    }
    else
    {
      yyerror("Error");
      exit(0);
    }
  }
  else
  {
    p->type = 0;
  }
  
  return p;
}
 
AST_NODE *link_s_expr(AST_NODE *currentList, AST_NODE *newNode)
{
  // if (newNode->type == 0)
  // {
  //   printf("link_s_expr called, linking newNode %lf\n",newNode->data.number.value);
  // }
  // else if (newNode->type == 1)
  // {
  //   printf("link_s_expr called, linking newNode %s\n",newNode->data.function.name);
  // }
  // else if (newNode->type == 2)
  // {
  //   printf("link_s_expr called, linking newNode %s\n",newNode->data.symbol.name);
  // }
  // else
  // {
  //   printf("Error, link_s_expr with invalid newNode");
  // }

  if (currentList == NULL)
  {
    return newNode;
  }
  else
  {
    //printf("%d\n", currentList->type);
    newNode->nextAST = currentList;
    currentList->previous = newNode;
    return newNode;
  }
}

AST_NODE *link_to_symbol(char *symbolName, AST_NODE *arg_list)
{
  //printf("link_to_symbol called for symbol %s, linkin arg_list %lf\n", symbolName, arg_list->data.number.value);
  AST_NODE *p = symbol(symbolName);
  p->data.symbol.arg_list = arg_list;
  arg_list->parent = p;
  return p;
}

AST_NODE *link_arg_list(char *symbolName, AST_NODE *arg_list)
{
  //printf("link_arg_list called, linking new symbol %s\n", symbolName);
  AST_NODE *p = symbol(symbolName);
  if (arg_list != NULL)
  {
    p->data.symbol.arg_list = arg_list;
    //printf("finished linking arglist. symbol %s linked to existing list %s\n", symbolName, arg_list->data.symbol.name);
  }

  return p;
}

LINKED_LIST *user_let_elem(char *userFuncName, AST_NODE *arg_list, AST_NODE *s_expr_list)
{
  //printf("test in user_let_elem\n");
  //printf("user_let_elem called, making letList for function %s, linking arg_list %s, linking s_expr_list %s\n", userFuncName, arg_list->data.symbol.name, 
  //          s_expr_list->data.function.name);
  struct linked_list *p;
  size_t llSize;

  llSize = sizeof(struct linked_list);
  if ((p = malloc(llSize)) == NULL)
    yyerror( "out of memory" );
  p->name = malloc((sizeof(userFuncName)) * sizeof(char));

  p->name = userFuncName;
  p->type = 3;
  p->value = s_expr_list;
  if (arg_list != NULL)
  {
    p->param_list = arg_list;
  }
  return p;

}

// create a node for a function
AST_NODE *function(char *funcName, AST_NODE *s_expr_list)
{
    //printf("function called, creating function node for %s\n", funcName);
    AST_NODE *p;
    size_t nodeSize;
    double readValue;

    // allocate space for the fixed sie and the variable part (union)
    nodeSize = sizeof(AST_NODE) + sizeof(FUNCTION_AST_NODE);
    if ((p = malloc(nodeSize)) == NULL)
        yyerror("out of memory");

    if(strcmp (funcName, "read") == 0)
    {
      printf("\nEnter value: ");
      scanf("%lf", &readValue);
      getc(stdin);
      p->type = 0;
      p->data.number.value = readValue;
    }
    else if (strcmp (funcName, "rand") == 0)
    {
      p->type = 0;
      p->data.number.value = rand();
    }
    else
    {
      p->type = FUNC_TYPE;
      p->data.function.name = funcName;
      if (s_expr_list != NULL)
      {
        p->data.function.op1 = s_expr_list;
        s_expr_list->parent = p;
      }
      if (s_expr_list->nextAST != NULL)
      {
        p->data.function.op2 = s_expr_list->nextAST;
        s_expr_list->nextAST->parent = p;
      }
    }

    return p;
}

AST_NODE *conditional(AST_NODE *conditionalStatement, AST_NODE *conditional1, AST_NODE *conditional2)
{
  AST_NODE *p;
  size_t nodeSize;

  // allocate space for the fixed sie and the variable part (union)
  nodeSize = sizeof(AST_NODE) + sizeof(FUNCTION_AST_NODE);
  if ((p = malloc(nodeSize)) == NULL)
        yyerror("out of memory");

  p->type = CONDITIONAL_TYPE;
  p->data.conditional.name = conditionalStatement->data.function.name;
  p->data.conditional.conditionalStatement = conditionalStatement;
  p->data.conditional.conditional1 = conditional1;
  p->data.conditional.conditional2 = conditional2;
  conditionalStatement->parent = p;
  conditional1->parent = p;
  conditional2->parent = p;
    
  return p;
  
}


// free a node
void freeNode(AST_NODE *p)
{
    if (!p)
       return;
       
    if (p->type == FUNC_TYPE)
    {
        free(p->data.function.name);
        freeNode(p->data.function.op1);
        freeNode(p->data.function.op2);
    }
        
    free (p);
}

double eval_user_func(AST_NODE *funcCall, LINKED_LIST *userFunc)
{
  //set the symbols in arg list value to the params passed in func call
  AST_NODE *funcPointer = userFunc->value;
  int flag = 1;
  double returnValue;
  double tempValue;
  if (userFunc->param_list != NULL)
  {
    AST_NODE *p = funcCall->data.symbol.arg_list;
    AST_NODE *a = userFunc->param_list;
    while (flag == 1)
    {
    //set the value
      tempValue = eval(p);
      a->data.symbol.value = tempValue;
      //printf("set value of argument %s to %lf\n", a->data.symbol.name, a->data.symbol.value);
    //are there more values to set?
      if (a->data.symbol.arg_list != NULL)
      {
      //there are, lets set them
        a = a->data.symbol.arg_list;
        p = p->nextAST;
      }
      else
      {
      //there aren't, lets set the flag
        flag = 2;
      }
    }
  
  //the values have been taken from the func call and given to the userFunc argList
  //Now we need to put these values into the userFunc's functions, so we can call eval on them.
    if (funcPointer->data.function.op1 != NULL)
    {
      //printf("find_and_replace_symbols called on %s\n", funcPointer->data.function.op1->data.function.name);
      find_and_replace_symbols(userFunc->param_list, funcPointer->data.function.op1);
    }
    if (funcPointer->data.function.op2 != NULL)
    {
      //printf("find_and_replace_symbols called on %s\n", funcPointer->data.function.op2->data.function.name);
      find_and_replace_symbols(userFunc->param_list, funcPointer->data.function.op2);
    }
  }
  //userFunc's functions should not have any more symbols. Because of this, they should be able to properly evaluated by the 'eval' function
  returnValue = eval(userFunc->value);
  //printf("eval_user_func completed, value calculated to be %lf\n", returnValue);
  return returnValue;
}

void find_and_replace_symbols(AST_NODE *arg_list, AST_NODE *currentNode)
{
  if (currentNode->type == 0)
  {
    //ignore it, move on
  }
  else if (currentNode->type == 1)
  {
    //printf("found function node, calling on ops\n");
    //call on both ops
    if (currentNode->data.function.op1 != NULL)
    {
      //printf("calling on op1\n");
      find_and_replace_symbols(arg_list, currentNode->data.function.op1);
    }
    if (currentNode->data.function.op2 != NULL)
    {
      //printf("calling on op2\n");
      find_and_replace_symbols(arg_list, currentNode->data.function.op2);
    }
  }
  else if (currentNode->type == 3)
  {
    //call on all 3 ops
    find_and_replace_symbols(arg_list, currentNode->data.conditional.conditionalStatement);
    find_and_replace_symbols(arg_list, currentNode->data.conditional.conditional1);
    find_and_replace_symbols(arg_list, currentNode->data.conditional.conditional2);
  }
  else
  {
    //printf("found symbol node, symbol is %s\n", currentNode->data.symbol.name);
    //found a symbol that needs to be replaced
    //search through the arglist for a matching name, then change the type to number, and change data to proper data
    int flag = 1;
    AST_NODE *arg_listPointer = arg_list;
    while (flag == 1)
    {

      if (strcmp(arg_listPointer->data.symbol.name, currentNode->data.symbol.name) == 0)
      {
        //printf("found match for %s, value is %lf\n", currentNode->data.symbol.name, arg_listPointer->data.symbol.value);
        //found the match, alter the node as needed
        AST_NODE *tempNode = number(arg_listPointer->data.symbol.value);
        currentNode->type = 0;
        currentNode->data = tempNode->data;
        flag = 2;
      }
      else
      {
        //current one isnt a match, search next. if there are no more to search, error out
        if ( arg_listPointer->data.symbol.arg_list != NULL)
        {
          arg_listPointer = arg_listPointer->data.symbol.arg_list;
          //printf("checking next argument %s, %lf\n", arg_listPointer->data.symbol.name, arg_listPointer->data.symbol.value);
        }
        else
        {
          //error
          //printf("error in find_and_replace_symbols\n");
          exit(-1);
        }
      }
    }
  }
  //all symbols should be replaced at this point
}

double evalSymbol(AST_NODE *currentNode, LINKED_LIST *toSearch, char *symbol)
{
  if ( toSearch == NULL )
  {
    if ( currentNode->parent != NULL )
    {
      return evalSymbol( currentNode->parent, currentNode->parent->scope, symbol );
    }
    else
    {
      printf("Error test1");
      exit(-1);
    }
  }
  else if ( strcmp( toSearch->name, symbol ) == 0 )
  {
      if (toSearch->value->type == 0)
      {
        return toSearch->value->data.number.value;
      }
      else if (toSearch->type == 3)
      {
        double tempValue;
        if (strcmp(symbol, currentNode->data.function.op1->data.symbol.name) == 0)
        {
          //printf("eval_user_func called on function %s, with letList %s\n", currentNode->data.function.op1->data.symbol.name, toSearch->name);
          tempValue = eval_user_func(currentNode->data.function.op1, toSearch);
          return tempValue;
        }
        else
        {
          tempValue = eval_user_func(currentNode->data.function.op2, toSearch);
          return tempValue;
        }
      }
      else
      {
      AST_NODE *p;
      size_t nodeSize;
      nodeSize = sizeof(AST_NODE) + sizeof(NUMBER_AST_NODE);
      if ((p = malloc(nodeSize)) == NULL)
        yyerror("out of memory");

      p->type = NUM_TYPE;
      p->data.number.value = eval(toSearch->value);
      freeNode(toSearch->value);
      toSearch->value = p;
      return p->data.number.value;
      }
  }
  else
  {
    if ( toSearch->next != NULL )
    {
        return evalSymbol( currentNode, toSearch->next, symbol);
    }
    else
    {
      if(currentNode->parent == NULL)
      {
        //printf("%s\n",toSearch->name);
        yyerror("Invalid symbol - undeclared previously");
        exit(0);
      }
      return evalSymbol( currentNode->parent, currentNode->parent->scope, symbol);
    }
  }
  //printf("evalSymbol called on symbol %s\n", symbol);
  printf("Error, reached end of evalSymbol\n");
  return 0;
}

double eval(AST_NODE *p)
{
   if (!p)
   {
      return -1;
   }
   
   double op1, op2;
   int funcEnum;
   int tempInt;
   double tempValue;
  if ( p->type == 3 )
  {
    funcEnum = resolveFunc(p->data.conditional.name);
    if (funcEnum == 17)
    {
      op1 = eval(p->data.conditional.conditionalStatement->data.function.op1);
      op2 = eval(p->data.conditional.conditionalStatement->data.function.op2);
      if (op1 < op2)
      {
        return eval(p->data.conditional.conditional1);
      }
      else
      {
        return eval(p->data.conditional.conditional2);
      }
    }
    else if(funcEnum == 18)
    {
      op1 = eval(p->data.conditional.conditionalStatement->data.function.op1);
      op2 = eval(p->data.conditional.conditionalStatement->data.function.op2);
      if (op1 == op2)
      {
        return eval(p->data.conditional.conditional1);
      }
      else
      {
        return eval(p->data.conditional.conditional2);
      }
    }
    else if(funcEnum == 19)
    {
      op1 = eval(p->data.conditional.conditionalStatement->data.function.op1);
      op2 = eval(p->data.conditional.conditionalStatement->data.function.op2);
      if (op1 > op2)
      {
        return eval(p->data.conditional.conditional1);
      }
      else
      {
        return eval(p->data.conditional.conditional2);
      }
    }
    else
    {
      op1 = eval(p->data.conditional.conditionalStatement);
      if (op1 != 0)
      {
        return eval(p->data.conditional.conditional1);
      }
      else
      {
        return eval(p->data.conditional.conditional2);
      }

    }

  } 
  if ( p->type == 2 )
      {
        return evalSymbol(p->parent, p->parent->scope, p->data.symbol.name);
      }
   if ( p->type == 1 )
   {
      //printf("eval called on %s\n", p->data.function.name);
      
      funcEnum = resolveFunc(p->data.function.name);

      switch (funcEnum)
      {
        case 0:
          op1 = eval(p->data.function.op1);
          return -op1;
        case 1:
          op1 = eval(p->data.function.op1);
          return fabs(op1);
        case 2:
          op1 = eval(p->data.function.op1);
          return exp(op1);
        case 3:
          op1 = eval(p->data.function.op1);
          return sqrt(op1);
        case 4:
          op1 = eval(p->data.function.op1);
          op2 = eval(p->data.function.op2);    
          return ( op1 + op2 );
        case 5:
          op1 = eval(p->data.function.op1);
          op2 = eval(p->data.function.op2);
          return ( (op1) - (op2) );
        case 6: 
          op1 = eval(p->data.function.op1);
          op2 = eval(p->data.function.op2);  
          return ( op1 * op2 );
        case 7:
          op1 = eval(p->data.function.op1);
          op2 = eval(p->data.function.op2);  
          return ( op1 / op2 );
        case 8:
          op1 = eval(p->data.function.op1);
          op2 = eval(p->data.function.op2);
          return fmod( op1 , op2 ); 
        case 9:
          op1 = eval(p->data.function.op1);
          op2 = eval(p->data.function.op1);
          if ( op1 == 2.0 )
          {
            return ( log2(op2) );
          }
          else if( op1 == 10.0 )
          {
            return ( log10(op2) );
          }
          else
          {
            printf("Error in eval case 9(log). Invalid base");
            exit(-1);
          }
        case 10:
          op1 = eval(p->data.function.op1);
          op2 = eval(p->data.function.op2);
          return pow( op1 , op2 );
        case 11:
          op1 = eval(p->data.function.op1);
          op2 = eval(p->data.function.op2);
          if ( op1 >= op2 )
          {
            return op1;
          }
          else
          {
            return op2;
          }
        case 12: 
          op1 = eval(p->data.function.op1);
          op2 = eval(p->data.function.op2);
          if ( op1 <= op2 )
          {
            return op1;
          }    
          else
          {
            return op2;
          }
          break;
      case 13:
          op1 = eval(p->data.function.op1);
          return  exp2( op1 );
      case 14:
          op1 = eval(p->data.function.op1);
          return  cbrt( op1 );
      case 15:
          op1 = eval(p->data.function.op1);
          op2 = eval(p->data.function.op2);
          return  hypot( op1, op2 );
      case 16:
          //evaluate value and type

          //get value with eval recursive call
          op1 = eval(p->data.function.op1);

          //find type with evalForInt
          tempInt = evalForInt(p);
          if (tempInt == 0)
          {
            //output format = int
            printf("PRINT:%d\n", (int) op1);
          }
          else
          {
            //output format = double
            printf("PRINT:%.2lf\n", op1);
          }
          return op1;
          break;
      case 20: 
          op1 = rand();
          return op1;
          break;
      case 21:
          printf("\nEnter value: ");
          scanf("%lf", &op1);
          getc(stdin);
          return op1;
          break;    
        default:
          printf("Error: reached default in eval switch");
          return 0;
        }
      }
      else if ( p->type == 0 )
      {
        op1 = p->data.number.value;
        return op1;
      }
      
      else
      {
        printf("Error: eval passed non num/func token");
        exit(-1);
      }
      return 0;
            
} 