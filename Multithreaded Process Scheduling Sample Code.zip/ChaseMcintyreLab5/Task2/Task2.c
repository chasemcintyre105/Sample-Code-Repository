/**
* Name: Chase Mcintyre
* Lab/task: Lab 5 Task 2
* Date: 02/22/2018
**/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h> 
#include <sys/wait.h> 

#define MAGIC_NUMBER 10
#define A_LARGE_NUMBER 1000000

typedef enum {
PRIORITY_HIGH = 99,
PRIORITY_MEDIUM = 50,
PRIORITY_LOW = 1
} PRIORITY;



void *runner (void *thread_parameter)
{
	//first step is to cast the parameter to a string
	// this string represents its priority - high, medium, low
	char *priority = (char *) thread_parameter;
	int true = 1;
	long tempLong;
	//in an infinite loop 'while(true)' count down from a large #, when hitting 0 printf
	// the threadID and its priority
	while(true == 1)
	{
		for (int i = A_LARGE_NUMBER; i > 0; i--)
		{
			//simulating work
		}
		//print thread ID and priority
		//tempLong = (long) pthread_self();
		printf("THREAD:%ld  PRIORITY:%s\n", (long)pthread_self(), priority);
	}

	return thread_parameter;
}

int main(int argc, char *argv[])
{
	//Need to make:
		/* schedParam.sched_priority = enum value
		   attr - format according to the provided code
		   each *3, one for each scheduling method
		   */

	//1 - low priority - default/other
	pthread_t tidsLow[MAGIC_NUMBER];
	for (int i = 0; i < MAGIC_NUMBER; i++)
	{
		pthread_t uniqueTid;
		tidsLow[i] = uniqueTid;
	}
	pthread_attr_t attrLow;
	struct sched_param schedParamLow;

	pthread_attr_init(&attrLow);
	pthread_attr_setscope(&attrLow, PTHREAD_SCOPE_PROCESS);
	schedParamLow.sched_priority = PRIORITY_LOW;
	pthread_attr_setinheritsched(&attrLow, PTHREAD_EXPLICIT_SCHED);
	pthread_attr_setschedpolicy(&attrLow, SCHED_OTHER);
	pthread_attr_setschedparam(&attrLow, &schedParamLow);

	//We won't create the thread until all 3 sched's and params are created

	//2 - Medium priority - FIFO
	pthread_t tidsMedium[MAGIC_NUMBER];
	for (int i = 0; i < MAGIC_NUMBER; i++)
	{
		pthread_t uniqueTid;
		tidsMedium[i] = uniqueTid;
	}
	pthread_attr_t attrMedium;
	struct sched_param schedParamMedium;

	pthread_attr_init(&attrMedium);
	pthread_attr_setscope(&attrMedium, PTHREAD_SCOPE_PROCESS);
	schedParamMedium.sched_priority = PRIORITY_MEDIUM;
	pthread_attr_setinheritsched(&attrMedium, PTHREAD_EXPLICIT_SCHED);
	pthread_attr_setschedpolicy(&attrMedium, SCHED_OTHER);
	pthread_attr_setschedparam(&attrMedium, &schedParamMedium);

	//3 - High priority - RR
	pthread_t tidsHigh[MAGIC_NUMBER];
	for (int i = 0; i < MAGIC_NUMBER; i++)
	{
		pthread_t uniqueTid;
		tidsHigh[i] = uniqueTid;
	}
	pthread_attr_t attrHigh;
	struct sched_param schedParamHigh;

	pthread_attr_init(&attrHigh);
	pthread_attr_setscope(&attrHigh, PTHREAD_SCOPE_PROCESS);
	schedParamHigh.sched_priority = PRIORITY_HIGH;
	pthread_attr_setinheritsched(&attrHigh, PTHREAD_EXPLICIT_SCHED);
	pthread_attr_setschedpolicy(&attrHigh, SCHED_OTHER);
	pthread_attr_setschedparam(&attrHigh, &schedParamHigh);

	// schedparam and attr created for each of the scheduling methods
	// Next step is to create arrays of pthread_id's for each type
	// How many am I supposed to create?
	// I have altered the above blocks to create these tid arrays, up to a magic number

	/* pthread_create(&tid, &attr, &runner, &argv);
		pthread_join(tid, NULL);
		pthread_attr_destroy(&attr); */
	for (int i = 0; i < MAGIC_NUMBER; i++)
	{
		pthread_create(&tidsLow[i], &attrLow, runner, (void *) "Low");
		pthread_create(&tidsMedium[i], &attrMedium, runner, (void *) "Medium");
		pthread_create(&tidsHigh[i], &attrHigh, runner, (void*) "High");
	}
	while (getchar() != 'q')
	{
		sleep(1);
	}
	exit(0);
}