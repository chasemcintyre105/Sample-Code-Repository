/**
* Name: Chase Mcintyre
* Lab/task: Lab 5 Task 1
* Date: 02/18/2018
**/

#include <stdio.h>
#include <stdlib.h>


int main()
{
	//firstly, read from the input file

	double alphaValue;
	double oneMinusAlpha;
	double pastAverage = -1;
	double presentAverage;
	int timeCounter = 0;
	char *fileName = "input.txt";
	FILE *file;
	file = fopen(fileName, "r");
	if (!file)
	{
		printf("Error opening input file");
	}

	// get alpha
	fscanf(file, "%lf", &alphaValue);
	oneMinusAlpha = (1 - alphaValue);
	printf("Alpha value of %.2lf received\n", alphaValue);

	// now, in a loop, calculate the burst
	while (	fscanf(file, "%lf", &presentAverage) != EOF )
	{
		//printf("%.2lf\n", presentAverage);
		if (pastAverage == -1)
		{
			pastAverage = presentAverage;
			//printf("pastAverage set to %.2lf\n", pastAverage);
		}

		// the burst should look at the past average and the present average, find the middle,
		// print that value, then assign that value to the past average
		printf("Burst 0 is: %.0lf\n", presentAverage);
		pastAverage = ( (alphaValue * presentAverage) + (oneMinusAlpha * pastAverage) );
		printf("Tau %d is: %.2lf\n", timeCounter, pastAverage);


		timeCounter++;
	}

}