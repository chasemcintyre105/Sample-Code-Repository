/**
* Name: Chase Mcintyre
* Lab/task: Lab 5 Task 3
* Date: 02/23/2018
**/


// Notable aspects from in class notes
/*  - We will be simulating this queue by using a simple array of burst times
	- The scheduling algorithm searches (at every time tick) for which element 
		should be the next to be processed - no reordering or movement of inputs, just selection
	- We dont read all the input at once - we read it as needed
	- inside of while loop, on each time tick you should check if the current time is equal to the next 
		incoming arrival time
		- if it is, you put the new arrival into the queue, and scan in the next item as the next 
			incoming process
		- just use a counter to keep track of where in the array to put items in
	- Events that produce output:
		- 1) A process has arrived
		- 2) A process has finished - pick a new one or go idle (reset remainingQuantum for RR 			scheduling)
		- 3) A quantum has expired - the remainingQuantum has reached 0
		- Output the CPU status ONLY on these events
			- The first line of output is the time - 
					"Tn:"
			- The second line is information about the current process - 
					"CPU: Pn(Pn.burstTimeRemaing)"
			- The third line is the queue - 
					Prints "Pn(Pn.burstTimeRemaining)"
					- to get a waiting process, it 
					(must not be the current process && must have burstTimeRemaining > 0)
	QUEUE notes
	-FCFS
		- does a linear search of the queue
		- find the first process that has work to do
	- RR
		- needs to check the quantum 'stuff' and for dead processes
		- checks the queue starting at the current process, goes to the end, then loops 
			around to the start and continues back to the current process
	- SJF
		- searches the queue for smallest burstTime IF there is no current process
		- only searches when a process is finished
	- SRTF
		- Tell SJF it has nothing to work on every time tick, so the shortest exisiting process 
			in the queue is always the active process


	General program flow notes:
	- to avoid repeated checking of schedule type
	- int (*scheduler)(int);
	- int rr(int current_process);
	- setschedulingalg
		- set_scheduler_function
			- reads in the first string, checks if strcmp("SRTF" == string) { set scheduler = &SRTF }
			- read in the quantum in this function as well
	- simulation()
	- workRemains()
	- checkForEvent()
	- int countWaitingProcess(selectedProcess, selectedProcess.index)


	int process_NUM_OF_PROCESSES;
	int full_quantum;
	int remaining_quantum;

	int (*scheduler)(int);
	int rr (int currentProcess);
	int srtf(int currentProcess);
	int fcfs (int curr..);
	int sjf (...);
	void set_scheduling_algorithm();
	void simulation();
	int work_remains();
	void display_CPU( int currentTime, int currentProcess, int scan_index );
	int count_waiting_processes ( int currentProcess, int scan_index );
	int main(int argc, argv[]); 
	*/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h> 
#include <sys/wait.h> 
#include <string.h>

#define PROCESS_COUNT 3

int process_NUM_OF_PROCESSES; // counter for what index to load items into the queue
int full_quantum; //the quantum time of RR
int remaining_quantum; //the currentProcesses remaining quantum time
int processQueue[PROCESS_COUNT]; //Contains the exisitng processes
char *fileName; 
FILE *file;
char *schedMethod;
struct sched_param schedParam;
pthread_attr_t attr;
int scheduler; //holds the enum value of the mode
int nextArrivalTime;
int currentTime;
int currentProcess;
double totalWaitingTime;

void processCompletion(); //handles the various tasks of process completion
void processArrival(); //handles the various tasks of process arrival
int schedulerControl(int currentProcess);	//choose which scheduling submethod to call?
int rr (int currentProcess); //scans queue for the next process to choose
int srtf(int currentProcess); //scans queue for the next process to choose
int fcfs (int currentProcess); //scans queue for the next process to choose
int sjf (int currentProcess); //scans queue for the next process to choose
void set_scheduling_algorithm(); //Working on, mostly done
void simulation(); //runs the program
int work_remains(); //checks the queue/cpu to see if any remaining processes remain
void display_CPU( int currentTime, int currentProcess); //displays cpu/queue information
double count_waiting_processes ( int currentProcess); //counts processes in queue waiting

typedef enum {
RR = 1,
FCFS = 2,
SJF = 3,
SRTF = 4
} PRIORITY;

int main(int argc, char *argv[])
{
	/* Nick says - - Task 3 main should contain setschedulingalg, and simulation */
	/* the first step should be to read in the first line of input and act according to the 
		received string
		This should be done in set_scheduling_algorithm */
	set_scheduling_algorithm();

	/* We have read the first line of input and determined the scheduling method
	  Now, we need to run the simulation */
	simulation();

	return 0;
}

void simulation()
{
	/* Here we will go about actually running the scheduling process
	   simulation() should call:
	   		rr() //
	   		srtf() //
	   		fcfs() //
	   		sjf() //
	   		work_remains() //
	   		display_CPU() //
	   		count_waiting_processes() // 
	   */
	/*
	We will need to encapsulate the entire process of a 'time tick' inside a while loop
	This while loop should run until some condition is met - what condition?
	The condition could be until !work_remains(), this seems to be the natural route 
	Before we can call this method we need to read in the first process, so work_remains() doesnt
		incorrectly return false
	When we read it in, we need to deal with: arrivalTime and burstTime
	burstTime can simply be stored in the int[]queue
	arrivalTime can be stored in some temp variable, that should be rewritten each time the
		value of the time line is equal to it
	When arrivalTime is overwritten, it should be overwritten with the next process's arival time
	burstTime should only be read in and stored when its respective arrivalTime is reached
	We will need some form of counter to track what the value of the current timeslot is
	This can simply be stored in an int that is ++'d each itteration of the while loop
	*/

	//Instantiate basic variables
	currentTime = 0;
	currentProcess = -1;
	process_NUM_OF_PROCESSES = 0;
	totalWaitingTime = 0;
	for(int i = 0; i < PROCESS_COUNT; i++)
	{
		processQueue[i] = 0;
	}

	//Read in the first arrivalTime
	fscanf(file, "%d", &nextArrivalTime);


	//Start the while loop
	while (work_remains() == 1)
	{
		/* we can assume work does remain by reaching this line
			the first thing we need to do is check if a process has arrived */
		if(currentTime == nextArrivalTime)
		{
			processArrival();
		}
		/* We have processed any ariving processes
			Now we need to ensure our CPU contains the correct process */
		currentProcess = schedulerControl( currentProcess );
		totalWaitingTime += count_waiting_processes(currentProcess);
		
		/* We have ensured that the currentProcess is the correct one
			Now we need to 'do work' for this timeslot 
			We should only do this is the currentProcess != -1
			*/ 
		if (currentProcess != -1)
		{
			processQueue[currentProcess]--;
			currentTime++;
			if (scheduler == RR)
			{
				remaining_quantum--;
			}
			else
			{
				remaining_quantum = 100;
			}
		
			/* We have 'done work' on the currentProcess. Several checks must be run on the new 
				currentProcess burstTime */
			if (processQueue[currentProcess] == 0)
			{
				//the currentProcess has finished its work, we need to move onto the next process
				processCompletion();
			}
			else
			{
				/* the currentProcess hasnt finished its work, but we need to check
					its quantum still */
				if (remaining_quantum == 0)
				{
					//we need to find the next RR process
					//printf("Quantum reached 0 - calling scheduler control in sim with value %d as current process\n", currentProcess);
					currentProcess = schedulerControl(currentProcess);
					//if done, currentProcess is now -1
					//we also need to display_CPU() in this event
					//printf("Event occured - quantum has reached 0\n");
					display_CPU(currentTime, currentProcess);
				}
			}
		}
		/* We have reached the end of this iteration, we need to take several
			steps to ensure the program executes correctly
				Update the totalWaitingTime of processes
				Update the currentTime  */
		
		//printf("test - totalWaitingTime at T%d = %lf\n",currentTime-1, totalWaitingTime);	
	}
	//Calculate the average waiting time
	totalWaitingTime += count_waiting_processes(currentProcess);
	//printf("test - totalWaitingTime at T%d = %lf\n",currentTime, totalWaitingTime);
	//totalWaitingTime += 2;
	double averageWaitingTime = totalWaitingTime/PROCESS_COUNT;
	printf("AVERAGE WAITING TIME: %.2lf\n", averageWaitingTime);
	exit(0);

}

double count_waiting_processes ( int currentProcess )
{
	/* The function of this method is to count the number of waiting processes
		To do this, search linearly through processQueue for any processes that:
			Are not currentProcess
			have burstTime > 0
		*/
	double total = 0;
	for (int i = 0; i < PROCESS_COUNT; i++)
	{
		if (i != currentProcess && processQueue[i] > 0)
		{
			total++;
		}
	}

	return total;
}

void processCompletion()
{
	/* A process has completed the work it needs to do
		we need to handle this situation differently for the different scheduling modes
		We need to displayCPU() because this event should trigger output
	*/

	/* RR - We need to move on to the next process, and reset the remainingQuantum 
		rr() resets the quantum, so long as the currentProcess argument has a burstTime
		of 0
		so, calling schedulerControl(currentProcess) should:
			get the next process to be worked on
			reset the quantum  */
	/* SRTF - We need to move on to the next process
		can be done with schedulerControl(currentProcess) */
	/* FCFS - We need to move on to the next process
		can be done with ... */
	/* SJF - Move on to the next process, can be done with ... */
	//It seems that simply calling schedulerControl(currentProcess) should be enough here
	currentProcess = schedulerControl(currentProcess);
	//printf("Event occured - process has completed work\n");
	display_CPU(currentTime, currentProcess);
	//printf("test - calling work remains\n");
}

void display_CPU( int currentTime, int currentProcess)
{
	/* This method is only triggered when an event that causes output to happen happens
		Need to output: 
		current CPU information (<idle> if == -1)
		current queue information (<empty> if empty)
		current time */
	//print the currentTime
	printf("T%d:\nCPU: ", currentTime);

	//print the currentProcess, or <idle> if its -1
	if ( currentProcess == -1 )
	{
		printf("<idle>\nQUEUE: ");
	}
	else
	{
		printf("P%d(%d)\nQUEUE: ", (currentProcess+1), processQueue[currentProcess]);
	}

	/*printf the queue, not counting the current process, or <empty> if its empty
		Scan through the queue printing out any elements meeting the criteria of:
		Not the currentProcess
		burstTime > 0
		*/
	int emptyQueueFlag = 0;
	for (int i = 0; i < 3; i++)
	{	
		if ( i != currentProcess && processQueue[i] != 0)
		{
			printf("P%d(%d) ", (i+1), processQueue[i] );
			emptyQueueFlag = 1;
		}
	}
	if (emptyQueueFlag == 0)
	{
		printf("<empty>");
	}
	printf("\n\n");

}

void processArrival()
{

	/* a process has arrived
		Several events need to take place */
	//add the process's burstTime to the queue at process_NUM_OF_PROCESSES
	fscanf( file, "%d", &processQueue[process_NUM_OF_PROCESSES] );
	//printf("test - scanned in value %d to queue at index %d\n", 
			//processQueue[process_NUM_OF_PROCESSES], process_NUM_OF_PROCESSES);

	/* scan in nextArrivalTime
		what if the next arrival time is the EOF?
		fscanf should return 0 if it hits EOF, catch this scenario */
	if(fscanf(file, "%d", &nextArrivalTime) == 0)
	{
		//What should I do in this scenario?
		// I shouldset the nextArrivalTime to -1 as a flag
		nextArrivalTime = -1;
	}

	/* we may need to adjust the CPU, QUEUE, and current process depending on the scheduling mode. 
		If the scheduling mode is RR, we dont need to change this. 
		If the mode is FCFS, we dont need to change this.
		If the mode is SJF , we dont need to change this.
		If the mode is SRTF, we might need to change this
		If this is the first process to arrive, or there are no other processes to be worked
			on, we can simply make it the current process and continue onwards
	*/

	if (currentProcess == -1)
	{
		currentProcess = process_NUM_OF_PROCESSES;
	}
	else
	{
		//there exists a current process and a new process has arrived.
		//here, only SRTF needs to compare their burst times
		if (scheduler == SRTF)
		{
			currentProcess = schedulerControl( currentProcess );
		}
	}
	//The CPU should be up to date with the new arrival information
	//The Queue should be up to date with the new arrival information

	//increment num of processes
	process_NUM_OF_PROCESSES++;

	//this is an event that produces output, so output the updated information
	//printf("Event occured - process has arrived\n");
	display_CPU(currentTime, currentProcess);
}

int schedulerControl(int currentProcess)
{
	/* This fucntion is intended to handle the different scheduling modes and return
		the int index of the next process to be worked on */

	int processIndex = -1;

	if (scheduler == RR)
	{
		//printf("in schedulerControl, calling rr() on process %d\n", currentProcess);
		processIndex = rr(currentProcess);
		//printf("rr() completed, new process - %d\n", processIndex);
	}
	else if (scheduler == FCFS)
	{
		processIndex = fcfs(currentProcess);
	}
	else if (scheduler == SJF)
	{
		processIndex = sjf(currentProcess);
	}
	else
	{
		processIndex = srtf(currentProcess);
	}

	return processIndex;
}

void set_scheduling_algorithm()
{
	//Open the file
	fileName = "input.txt";
	file = fopen(fileName, "r");
	if (!file)
	{
		printf("Error opening input file");
	}
	
	//Read in the first string
	schedMethod = malloc(sizeof(char) * 10);
	fscanf(file, "%s", schedMethod);
	
	//If its RR, read in the Quantum
	//For all of them
	if (strcmp(schedMethod, "RR") == 0)
	{
		fscanf(file, "%d", &full_quantum);
		remaining_quantum = full_quantum;
		scheduler = RR;
	}
	else if (strcmp(schedMethod, "FCFS") == 0)
	{
		scheduler = FCFS;
	}
	else if (strcmp(schedMethod, "SJF") == 0)
	{
		scheduler = SJF;
	}
	else
	{
		scheduler = SRTF;
	}
	//the scheduling algorithm has been set, we can return to main
}

int work_remains()
{
	/* Here we need to check and see if any work remains to be done
		We need to check the CPU, the Queue, and ensure that there are no processes
			set to arrive that simply havnt arriven
		How do we check the CPU? we check the currentProcess variable
		How do we check the queue? Scan through it linearly checking for any 
			processes that: (have a burstTimeRemaining > 0)
		How do we check for arriving processes?
			slightly more complicated: we need to compare the currentTime and
			nextArrivalTime. If (currentTime > nextArrivalTime) there should be no processes
			enroute
		Return Value: this function should return a 1 if work remains, or a 0 if no work remains
	*/
	int workFlag = 0;
	//printf("test - in work_remains with currentProcess=%d\n",currentProcess);

	/*Check the CPU (currentProcess)
	  if currentProcess == -1, it is currently not executing any process*/
	if (currentProcess != -1)
	{
		//its not -1, so CPU has a process
		workFlag = 1;
		return workFlag;
	}
	/* Check the Queue */
	for(int i = 0; i < PROCESS_COUNT; i++)
	{
		//check the value of the process at this index, if it is ever > 0 work remains
		if( processQueue[i] > 0 )
		{
			workFlag = 1;
			return workFlag;
		}
	}
	/* check for arriving processes */
	if( currentTime <= nextArrivalTime )
	{
		workFlag = 1;
		return workFlag;
	}
	return workFlag;
}

int rr (int currentProcess)
{
	//round robin process selector

	int newProcessIndex = -1;
	/* We need to check the quantum information to determine if a new process is necesarry 
		we need a new process if - the remainingQuantum == 0, or burstTime == 0 */
	if (remaining_quantum == 0 || processQueue[currentProcess] == 0)
	{
		//printf("in rr(), selecting a new process\n");
		//We need a new process
		// We also need to reset the remaining quantum
		remaining_quantum = full_quantum;
		/* When selecting a new process with RR scheduling, we simply move onto the next 
			element in the queue that has a burstTime > 0, wrapping at the end of the queue
		   What if there are no reamining processes in the queue? How can we detect this, and 
		   how should we react?
		   Detection: have a for loop that checks a set number of burstTimes
		   Reaction: if this is the case, we return -1 as the newProcessIndex */
		// scan through the queue lookinf fr the next element that has work
		for (int i = (currentProcess+1)%PROCESS_COUNT; i != currentProcess; )
		{
			//check if the new index burst time != 0
			if (processQueue[i] != 0)
			{
				//printf("test - found a new process - %d\n", i);
				//this is the new process
				newProcessIndex = i;
				return newProcessIndex;
			}
			else
			{
				//increment i and move on
				i = (i+1)%PROCESS_COUNT;
			}
		}
		//if we hit this point than we have searched the queue and found no processes with burstTime
		// > 0. we return -1 for the new process index
		//printf("test - did not find a new process\n");
		return newProcessIndex;
	}
	else
	{
		//We don't need a new process
		return currentProcess;
	}
} 
int srtf(int currentProcess)
{
	//srtf process selector
	int newProcessIndex = -1;

	/* When selecting a new process for the SRTF mode, we need to do a linear search of the
		process queue and select the process with the lowest remaining burstTime
		We should do this regardless of the currentProcess's burstTime
		If only 0's are found, we should return -1
	*/

	//We need a new process
	//Search through the queue for the smallest burstTime > 0
	for(int i = 0; i < PROCESS_COUNT; i++)
	{
		//grab any burstTimes that are not 0
		if ( processQueue[i] != 0 )
		{
			//found a process that needs work, grab burstTime and compare against lowest found
			//is this the first non 0we have found?
			if( newProcessIndex == -1 )
			{
				// if this is the first process with work we have found...
				newProcessIndex = i;
			}
			else
			{
				// if the process at i is smaller than the previously found process...
				if( processQueue[i] < processQueue[newProcessIndex] )
				{
					newProcessIndex = i;
				}
			}
		}
	}
	//if the entire queue was 0's than newProcessIndex should. be -1
	return newProcessIndex;
} 
int fcfs (int currentProcess)
{
	//fcfs process selector
	int newProcessIndex = -1;
	/* When selecting a new process for the FCFS method, we simply move onto the next element in the
		processQueue. There should never a situation in which this is not true. There should never be
		a situation in which an element beyond currentProcess exists and isnt the desired next
		process
		 */
	//We should only need a new process if the current process's burstTime is 0
	if( processQueue[currentProcess] == 0)
	{
		//our current process is completed, we need to check if a new one exists
		if( (currentProcess + 1) < PROCESS_COUNT)
		{
			//another process does exist, so lets return it
			newProcessIndex = currentProcess + 1;
			return newProcessIndex;
		}
		else
		{
			//this is the last process in our queue, so lets return -1
			return newProcessIndex;
		}
	}
	else
	{
		//we dont need a new process
		return currentProcess;
	}
}
int sjf (int currentProcess)
{
	//sjf process selector
	int newProcessIndex = -1;
	/* When selecting a new process for the SJF mode, we need to search through the queue for the
		process that has the smallest (burstTime > 0) and return it
		We should only do this if the currentProcess burstTime == 0
		If queue only contains 0's, we should return -1;
	*/
	if( processQueue[currentProcess] == 0)
	{
		//We need a new process
		//Search through the queue for the smallest burstTime > 0
		for(int i = 0; i < PROCESS_COUNT; i++)
		{
			//grab any burstTimes that are not 0
			if ( processQueue[i] != 0 )
			{
				//found a process that needs work, grab burstTime and compare against lowest found
				//is this the first non 0we have found?
				if( newProcessIndex == -1 )
				{
					// if this is the first process with work we have found...
					newProcessIndex = i;
				}
				else
				{
					// if the process at i is smaller than the previously found process...
					if( processQueue[i] < processQueue[newProcessIndex] )
					{
						newProcessIndex = i;
					}
				}
			}
		}
		//if the entire queue was 0's than newProcessIndex should. be -1
		return newProcessIndex;
	}
	else
	{
		//We dont need a new process
		return currentProcess;
	}
}





































