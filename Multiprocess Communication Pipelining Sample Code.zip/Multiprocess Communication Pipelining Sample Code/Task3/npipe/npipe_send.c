#include	"npipe.h"

int main(int argc, char** argv) {
	char line[MAX_LINE];
	int pipe;
	
	int stat;
	if (stat = mkfifo("/tmp/ajsFIFO", 0600) < 0)
		oops("Cannot make FIFO", stat);
	
	// open a named pipe
	pipe = open("/tmp/ajsFIFO", O_WRONLY);
	
	while(1)
	{
		// get a line to send
		printf("Enter line: ");
		fgets(line, MAX_LINE, stdin);
		
		if (strcmp(line, "quit\n") == 0)
			break;
		
		// actually write out the data and close the pipe
		write(pipe, line, strlen(line));
	}
	// close the pipe
	close(pipe);
	return 0;
}

//Named pipe notes
/*
named pipe works much like the pipe from task 2 but with some key differences
	-Named pipes exist as special files within the file system
	-Processes with different origins can share data
	-When I/O is done the named pipe remains in the file system for later use
		-Must delete the pipe every single test run, or code will error out

TODO: combine the above functionalities into one file as described on the lab3 description on canvas.
you will be running the same program in two different terminal windows, one will detect that a fifo 
hasnt been created and will create one and go into sending mode, the second one will detect that a 
fifo has been made and will go into read mode
-------------------------------------------------------------------------------------
	-1) Check for existing fifo queue
		if(fifo queue does not exist)
		{
			set process to sending mode;
			create one, print this out, error out if it cant be created;
			create loop to receive userInput strings
			if (userInput == "switch")
			{
				switch to receiving mode;
			}

			if (userInput == "quit")
			{
				end process / exit(0);
			}
		}
		else (a fifo exists and was detected)
		{
			set process to reading mode;
			wait for messages;
			if (userInput == "switch")
			{
				set process to sending mode
			}
			if (userInput == "quit")
			{
				close fifo queue;
				end process / exit(0);
			}	
		}
------------------------------------------------------------------------------------------
	-A process will be set to sending mode if there is no existing fifo queue
		-it must create the fifo queue

	-When userInput = switch, then both terminals should receive this command
		-This means that the sender entering switch causes both the sender and the 
		receiver to switch
*/


