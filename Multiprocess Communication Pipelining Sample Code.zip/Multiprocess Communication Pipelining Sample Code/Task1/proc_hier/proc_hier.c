#include	<errno.h>
#include	<sys/types.h>
#include	<sys/wait.h>
#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<unistd.h>
#define oops(m) ({fprintf(stderr, "ERROR: %s\n", m); exit(-1);})
int main()
{
	
	pid_t pid1;

   
	/* fork a child process */
	pid1 = fork();
   


	if (pid1 < 0) /* error occurred */
		oops("Fork Failed!");
   	
	else if (pid1 == 0) 
	{ /* child process */
		//------------
		//left child of 1
		//------------
		//Must create the first fork of parent here, .1

		pid_t pid11 = fork();

		//error
		if (pid11 < 0)
		oops("Fork Failed!");

		//left child of 11
		//should be given value of 111
		else if (pid11 == 0)
		{
			//Child process
			//--------------
			//Left child of 1.1
			//--------------
			//Must create the first fork of parent here, for 1.1.1
			pid_t pid111 = fork();
			if (pid111 < 0)
			{
				oops("Fork Failed!");
			}
			else if (pid111 == 0)
			{
				//Child process
				//--------------
				//Left child of 1.1.1
				//--------------
				//do not create any more children - the forking ends here
				exit(0);
			}
			else
			{
				//Parent process exisiting here is: 1.1.1
				//do not create any more children - the forking ends here
				//print out 1.1.1 and pidID
				printf("Process 1.1.1 pid is: %d\n", getpid());
			}


		}
		//Parent process 11
		//should give birth to 112
		else
		{
			printf("Process 1.1 pid is: %d\n", getpid());
			//Parent process existing here is: 1.1
			//Must create the second fork here, for 1.1.2
			pid_t pid112 = fork();
			if (pid112 < 0)
			{
				oops("Fork Failed!");
			}
			else if (pid112 == 0)
			{
				//child process
				//left child of 1.1.2
				//do not create any more children - the forking ends here
				exit(0);
			}
			else
			{
				//Parent process exisiting here is: 1.1.2
				//do not create any more children  - the forking ends here
				//print out 1.1.2 and pidID
				printf("Process 1.1.2 pid is: %d\n", getpid());
			}

		}

		//printf("I am the child %d\n",getpid());
		
	}
	else 
	{ /* parent process */
		/* parent will wait for the child to complete */
		//---------------
		//Parent must create the second fork here, for .2
		//parent process existing here is 1
		printf("Process 1 pid is: %d\n", getpid());

		pid_t pid12 = fork();

		//error
		if(pid12 < 0)
		{
			oops("Fork Failed!");
		}

		else if( pid12 == 0 )
		{
			//Child process
			//--------------
			//left child of 1.2
			//--------------
			//Must create the first fork of parent here, for 1.2.1
			pid_t pid121 = fork();
			if (pid121 < 0)
			{
				oops("Fork Failed!");
			}
			else if (pid121 == 0)
			{
				//child process
				//do not create any more children  - the forking ends here
				exit(0);
			}
			else
			{
				//parent process exisiting here is 1.2.1
				//do not create any more children  - the forking ends here
				//print out 1.2.1 and pidID
				printf("Process 1.2.1 pid is: %d\n", getpid());
			}

		}

		else
		{
			printf("Process 1.2 pid is: %d\n", getpid());
			//parent process exitsing here is: 1.2
			//must create the second fork here, for 1.2.2
			pid_t pid122 = fork();
			if (pid122 < 0)
			{

			}
			else if (pid122 == 0)
			{
				//child process
				//do not create any more children  - the forking ends here
				exit(0);
			}
			else
			{
				//parent process existing here is 1.2.2
				//do not create any more children  - the forking ends here
				//print out 1.2.2 and pidID
				printf("Process 1.2.2 pid is: %d\n", getpid());
			}

		}

		//printf("I am the parent %d\n",getpid());
      	if (wait(NULL) < 0)
        printf("-1 from wait(NULL) with errno = %d\n", errno);
		
		printf("Child Complete\n");
		exit(0);
	}

}
