#include	<stdio.h>
#include	<unistd.h>

int main(int argc, char *argv[])
{
	printf("Process %s pid is: %d\n", argv[1], getpid());
}
