#include "messg.h"

MESSG msg_rcvd, msg_send;

STAT stat; // holds response codes from functions
key_t key; // "address" of the process queue

float avg = 0; //

int main(int argc, char *argv[])
{
	msg_send.priority = DEFAULT_PRIORITY; // or "type"; can be used for selective reception
	
	if (argc > 1)
		key = atoi(argv[1]);
	else 
		key = SRV_PORT;
	
	msg_send.sender = msgget(key, 0666 | IPC_CREAT); // 0666 will be explained later in the course
	if (msg_send.sender < 0)
		oops("SRV: FAILED TO CREATE MESSAGE QUEUE.\n",1);
	
	while (TRUE) // check the defines in the h file
	{
		// recall: the first part of the message (long) is mandatory
		// the system want size of your part
		// the last '0' tells the system to block
		// alternatively, IPC_NOWAIT could be used if no blocking needed (no in this program)
		stat = msgrcv(msg_send.sender, &msg_rcvd, sizeof(MESSG) - sizeof(long), DEFAULT_PRIORITY, 0);
		if (stat < 0)
		{
			printf("SRV: FAILED TO RECEIVE MESSAGE FROM CLIENT.\n");
			continue;
		}
		else
			printf("SRV: CLIENT %d REPORTS: %f\n", msg_rcvd.sender, msg_rcvd.num);
		
		avg = (avg + msg_rcvd.num )/2;
		
		msg_send.num = avg;
		stat = msgsnd(msg_rcvd.sender, &msg_send, sizeof(MESSG) - sizeof(long), 0);
		if (stat < 0)
			printf("SRV: FAILED TO SEND RESPONSE TO CLIENT.\n");
	}
	
	stat = msgctl(msg_send.sender, IPC_RMID, NULL);
	
	printf("SRV: AVERAGE NUMBER: %f\n", avg);
	
	exit(0);
}
