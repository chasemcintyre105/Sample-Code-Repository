#include	<sys/types.h>
#include	<stdio.h>
#include	<stdlib.h>
#include	<string.h>
#include	<unistd.h>

#define MAXLINE 1024
#define	oops(m,x)	{ perror(m); exit(x); }

int main(void)
{
	//One process (child process) gets messages from stdin, sends them to the writing side, until it gets STOP
	//Child should close writing door once it receives stop
	//Parent process gets messages, sends them to stdout, stops receives EOF
	int		n, fd[2];
	pid_t	pid;
	char	line[MAXLINE];
	char	line2[MAXLINE];

	if (pipe(fd) < 0)
		printf("Cannot create a pipe.");

	if ( (pid = fork()) < 0)
		printf("Cannot fork.");

	else if (pid == 0) /* child */
	{
		//"if the parent wants to receive data from the child it should close fd[1] and "
		// "child should close fd[0]"
		//so, close fd[0]
		close(fd[0]);
		//todo: set up loop which: receives from stdin, 
		char *userInput = malloc(sizeof(char *));

		do
		{
			//receive user input
			gets(userInput);
			//send userInput to the mailbox
			write(fd[1], userInput, strlen(userInput) );
			//redo this loop until user enters stop
		}
		while ( strcmp("stop", userInput) != 0 );
		close(fd[1]);

		// write(fd[1], "Message for the parent\n", 23);
		// n = read(fd[0], line, MAXLINE);
		// printf("%s", line);
		// close(fd[1]);
	}
	else /* parent */
	{
		//"if the parent wants to receive data from the child it should close fd[1] and "
		// "child should close fd[0]"
		//so, close fd[1]
		close(fd[1]);

		//todo: set up loop which: reads strings from mailbox and sends it to the stdout
		do
		{
			n = read(fd[0], line2, MAXLINE);
			printf("%s", line2);
		}
		while( strcmp(line2,"stop") != 0 );
		close(fd[0]);
		wait(NULL);
		exit(0);


		// write(fd[1], "Message for the child\n", 22);
		// n = read(fd[0], line2, MAXLINE);
		// printf("%s", line2);
		// close(fd[0]);
		// wait(NULL);
	}
}