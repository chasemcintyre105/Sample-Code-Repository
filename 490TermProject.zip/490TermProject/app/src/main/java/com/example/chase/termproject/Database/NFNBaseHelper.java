package com.example.chase.termproject.Database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.chase.termproject.Database.NearFieldNetworkingDbSchema.CardTable;
import com.example.chase.termproject.Database.NearFieldNetworkingDbSchema.ResumeTable;
public class NFNBaseHelper extends SQLiteOpenHelper
{

    private static final int VERSION = 3;
    private static final String DBNAME = "businessInfo.db";

    public NFNBaseHelper(Context context) { super(context, DBNAME, null, VERSION); }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("create table " + CardTable.CARDNAME + "(" +
        "_id  integer primary key autoincrement, " +
        CardTable.CardColumns.UUID + ", " +
        CardTable.CardColumns.CARDNAME + " TEXT, " +
        CardTable.CardColumns.CARDPHONE + " TEXT, " +
        CardTable.CardColumns.CARDEMAIL + " TEXT, " +
        CardTable.CardColumns.CARDEXPERIENCE + ", " +
        CardTable.CardColumns.CARDTAGS + ")"
        );

        db.execSQL("create table " + ResumeTable.RESUMENAME + "(" +
        "_id integer, " +
        ResumeTable.ResumeColumns.UUID + ", " +
        ResumeTable.ResumeColumns.RESUMENAME +  " TEXT, " +
        ResumeTable.ResumeColumns.RESUMECURRENTEMPLOYMENT + ", " +
        ResumeTable.ResumeColumns.RESUMELIVINGLOCATION + ", " +
        ResumeTable.ResumeColumns.RESUMEBIOGRAPHY + ", " +
        ResumeTable.ResumeColumns.RESUMEEXPERIENCE + ", " +
        ResumeTable.ResumeColumns.RESUMEEDUCATION + ")"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
