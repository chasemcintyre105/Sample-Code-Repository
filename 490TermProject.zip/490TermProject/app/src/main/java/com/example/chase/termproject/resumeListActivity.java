package com.example.chase.termproject;
import android.support.v4.app.Fragment;

public class resumeListActivity  extends SingleFragmentActivity {

    @Override
    protected Fragment createFragment()
    {
        return new resumeFragmentList();
    }

}
