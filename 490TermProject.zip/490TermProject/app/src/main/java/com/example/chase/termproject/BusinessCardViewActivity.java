package com.example.chase.termproject;

import android.content.Intent;
import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.UUID;

public class BusinessCardViewActivity extends AppCompatActivity {

    private String dummy_values[];
    private String dummy_tags[];

    private String newTags[];

    private businessCardItem bCard;
    private cardDbConnection cDBcon;

    private EditText name_edittext;
    private EditText phone_edittext;
    private EditText email_edittext;
    private TextView temp_textview;
    private Button tagMenuLeft;
    private Button tagMenuRight;
    private View experience_view;

    private int i = 0;
    private int j = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.business_card_view);
        final Resources res = getResources();
        Intent intent = getIntent();
        cardDbConnection cDBcon = cardDbConnection.getDbConnection(this);

        this.name_edittext = (EditText) findViewById(R.id.business_card_userName_edittext);
        this.phone_edittext = (EditText) findViewById(R.id.business_card_phoneNumber_edittext);
        this.email_edittext = (EditText) findViewById(R.id.business_card_emailAddress_edittext);
        this.tagMenuLeft = (Button) findViewById(R.id.business_card_menuLeft_button);
        this.tagMenuRight = (Button) findViewById(R.id.business_card_menuRight_button);

        if(intent.getStringExtra(res.getString(R.string.my_card_key)) != null)
        {
            UUID myuuid = new UUID(1, 1);
            this.bCard = cDBcon.getCard(myuuid);
            if(this.bCard == null)
            {
                this.bCard = new businessCardItem(myuuid);
            }
            prepareMyCard(res);
            tagMenuLeft.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v)
                {
                    updateTagsLeft(res);
                }
            });
            tagMenuRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v)
                {
                    updateTagsRight(res);
                }
            });
        }
        else if(intent.getStringExtra(res.getString(R.string.new_card_key)) != null)
        {
            this.bCard = new businessCardItem();
            prepareNewCard(res);
            newTags = new String[100];
            tagMenuLeft.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v)
                {
                    updateNewTagsLeft(res);
                }
            });
            tagMenuRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v)
                {
                    updateNewTagsRight(res);
                }
            });
        }

    }

    private void updateNewTagsRight(Resources res)
    {
        if(i < 97)
        {
            int flag = 0;
            String tempString;
            for (int x = 2; x < 6; x++) {
                temp_textview = (TextView) findViewById(x);
                tempString = temp_textview.getText().toString();
                if (tempString.compareTo("") == 0) {
                    flag = 1;
                }
            }
            if (flag == 0) {
                //store entered values
                for (int x = 2; x < 6; x++) {
                    temp_textview = (TextView) findViewById(x);
                    newTags[i] = temp_textview.getText().toString();
                    i++;
                    temp_textview.setHint(R.string.enter_skill_tag);
                    temp_textview.setText("");
                }

            }
        }

    }
    private void updateNewTagsLeft(Resources res)
    {
        if(i > 0)
        {
            //Save entered tags
            int iCount = 0;
            for(int x = 2; x < 6; x++)
            {
                temp_textview = (TextView) findViewById(x);
                if(temp_textview.getText() != "")
                {
                    newTags[i] = temp_textview.getText().toString();
                    i++;
                    iCount++;
                }
            }
            i -= iCount + 1;

            //restore previous tags
            for(int x = 5; x > 1; x--)
            {
                temp_textview = (TextView) findViewById(x);
                temp_textview.setText(newTags[i]);
                i--;
            }
            i++;
        }
    }

    private void updateTagsRight(Resources res)
    {
        if( i > dummy_tags.length)
        {
            i = 0;
        }
        for(int x = 2; x < 6; x++)
        {
            temp_textview = (TextView) findViewById(x);
            if(i < dummy_tags.length)
            {
                temp_textview.setText(dummy_tags[i]); i++;
            }
            else
            {
                temp_textview.setText(""); i++;
            }
        }


    }

    private void updateTagsLeft(Resources res)
    {
        i = Math.abs(i - 8);

        for(int x = 2; x < 6; x++)
        {
            temp_textview = (TextView) findViewById(x);
            if(i < dummy_tags.length)
            {
                temp_textview.setText(dummy_tags[i]); i++;
            }
            else
            {
                temp_textview.setText(""); i++;
            }
        }
    }

    private void prepareNewCard(Resources res)
    {
        this.name_edittext.setHint(res.getString(R.string.enter_name));
        this.phone_edittext.setHint(res.getString(R.string.enter_phone));
        this.email_edittext.setHint(res.getString(R.string.enter_contact_information));

        experience_view = (View) findViewById(R.id.business_card_experience_view1);
        ViewGroup parent = (ViewGroup) experience_view.getParent();
        int index = parent.indexOfChild(experience_view);

        //Experiences
        float layoutWeight = (float) .50;
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 60);
        layoutParams.weight = layoutWeight;
        layoutParams.gravity = Gravity.BOTTOM;
        //Experience 1
        temp_textview = new EditText(this);
        temp_textview.setId(j);
        j++;
        temp_textview.setHint(R.string.add_job_experience);
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);
        //Experience 2
        experience_view = (View) findViewById(R.id.business_card_experience_view2);
        parent = (ViewGroup) experience_view.getParent();
        index = parent.indexOfChild(experience_view);
        temp_textview = new EditText(this);
        temp_textview.setId(j);
        j++;
        temp_textview.setHint(R.string.add_job_experience);
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);

        this.i = 0;
        //Tags
        layoutWeight = (float) 45;
        layoutParams = new LinearLayout.LayoutParams(0, 80);
        layoutParams.weight = layoutWeight;
        layoutParams.gravity = Gravity.START;
        layoutParams.topMargin = 10;
        //Tag 1
        experience_view = (View) findViewById(R.id.business_card_tag_view1);
        parent = (ViewGroup) experience_view.getParent();
        index = parent.indexOfChild(experience_view);
        temp_textview = new EditText(this);
        temp_textview.setId(j);
        j++;
        temp_textview.setHint(R.string.enter_skill_tag);
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);
        //Tag 2
        experience_view = (View) findViewById(R.id.business_card_tag_view2);
        parent = (ViewGroup) experience_view.getParent();
        index = parent.indexOfChild(experience_view);
        temp_textview = new EditText(this);
        temp_textview.setId(j);
        j++;
        temp_textview.setHint(R.string.enter_skill_tag);
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);
        //Tag 3
        experience_view = (View) findViewById(R.id.business_card_tag_view3);
        parent = (ViewGroup) experience_view.getParent();
        index = parent.indexOfChild(experience_view);
        temp_textview = new EditText(this);
        temp_textview.setId(j);
        j++;
        temp_textview.setHint(R.string.enter_skill_tag);
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);
        //Tag 4
        experience_view = (View) findViewById(R.id.business_card_tag_view4);
        parent = (ViewGroup) experience_view.getParent();
        index = parent.indexOfChild(experience_view);
        temp_textview = new EditText(this);
        temp_textview.setId(j);
        j++;
        temp_textview.setHint(R.string.enter_skill_tag);
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);
    }

    private void prepareMyCard(Resources res)
    {
        this.dummy_values = res.getStringArray(R.array.dummy_my_card_array);
        this.dummy_tags = res.getStringArray(R.array.dummy_tag_array);

        StringBuilder experiencesString = new StringBuilder();
        for(int x = 0; x < dummy_values.length; x++)
        {
            experiencesString.append(dummy_values[x]);
            experiencesString.append('\0');
        }
        StringBuilder tagsString = new StringBuilder();
        for(int x = 0; x < dummy_tags.length; x++)
        {
            tagsString.append(dummy_tags[x]);
            tagsString.append('\0');
        }
        this.bCard.setCardExperiences(experiencesString.toString());
        this.bCard.setCardTags(tagsString.toString());

        this.name_edittext.setText(dummy_values[i]);
        i++;
        this.bCard.setCardName(this.name_edittext.getText().toString());

        this.phone_edittext.setText(dummy_values[i]);
        i++;
        this.bCard.setCardPhone(this.phone_edittext.getText().toString());

        this.email_edittext.setText(dummy_values[i]);
        i++;
        this.bCard.setCardEmail(this.email_edittext.getText().toString());

        experience_view = (View) findViewById(R.id.business_card_experience_view1);
        ViewGroup parent = (ViewGroup) experience_view.getParent();
        int index = parent.indexOfChild(experience_view);

        //Experiences
        float layoutWeight = (float) .50;
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 60);
        layoutParams.weight = layoutWeight;
        layoutParams.gravity = Gravity.BOTTOM;
        //Experience 1
        temp_textview = new EditText(this);
        temp_textview.setId(j);
        j++;
        temp_textview.setText(dummy_values[i]);
        i++;
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);
        //Experience 2
        experience_view = (View) findViewById(R.id.business_card_experience_view2);
        parent = (ViewGroup) experience_view.getParent();
        index = parent.indexOfChild(experience_view);
        temp_textview = new EditText(this);
        temp_textview.setId(j);
        j++;
        temp_textview.setText(dummy_values[i]);
        i++;
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);

        this.i = 0;
        //Tags
        layoutWeight = (float) 45;
        layoutParams = new LinearLayout.LayoutParams(0, 80);
        layoutParams.weight = layoutWeight;
        layoutParams.gravity = Gravity.START;
        layoutParams.topMargin = 10;
        //Tag 1
        experience_view = (View) findViewById(R.id.business_card_tag_view1);
        parent = (ViewGroup) experience_view.getParent();
        index = parent.indexOfChild(experience_view);
        temp_textview = new EditText(this);
        temp_textview.setId(j);
        j++;
        temp_textview.setText(dummy_tags[i]);
        i++;
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);
        //Tag 2
        experience_view = (View) findViewById(R.id.business_card_tag_view2);
        parent = (ViewGroup) experience_view.getParent();
        index = parent.indexOfChild(experience_view);
        temp_textview = new EditText(this);
        temp_textview.setId(j);
        j++;
        temp_textview.setText(dummy_tags[i]);
        i++;
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);
        //Tag 3
        experience_view = (View) findViewById(R.id.business_card_tag_view3);
        parent = (ViewGroup) experience_view.getParent();
        index = parent.indexOfChild(experience_view);
        temp_textview = new EditText(this);
        temp_textview.setId(j);
        j++;
        temp_textview.setText(dummy_tags[i]);
        i++;
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);
        //Tag 4
        experience_view = (View) findViewById(R.id.business_card_tag_view4);
        parent = (ViewGroup) experience_view.getParent();
        index = parent.indexOfChild(experience_view);
        temp_textview = new EditText(this);
        temp_textview.setId(j);
        j++;
        temp_textview.setText(dummy_tags[i]);
        i++;
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);
    }
    @Override
    public void onPause()
    {
        super.onPause();
        cardDbConnection.getDbConnection(this).addCard(this.bCard);
    }

}



//        int option_id = R.layout.widgets_activity_main;
//        View widget_background = (View) findViewById(R.id.home_widget_view);
//        ViewGroup parent = (ViewGroup) widget_background.getParent();
//        int index = parent.indexOfChild(widget_background);
//        widget_background = getLayoutInflater().inflate(option_id, parent, false);
//        parent.addView(widget_background, index);