package com.example.chase.termproject;

import android.content.Intent;
import android.nfc.NdefMessage;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import java.util.List;

public class tag_received extends AppCompatActivity {

    private List<businessCardItem> bCards;
    private List<resumeItem> rItems;
    private businessCardItem intentCard;
    private resumeItem intentResume;
    private NfcAdapter mNfcAdapter;
    private Button tag_received_save_button;
    private Button viewPagerCardsButton;
    private Button viewPagerResumesButton;
    private ViewPager tag_received_viewpager;
    private FragmentManager fm;
    private String cardString;
    private String resumeString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tag_received);
        this.tag_received_save_button = (Button) findViewById(R.id.tag_received_button);
        this.tag_received_viewpager = (ViewPager) findViewById(R.id.tag_received_viewpager);
        this.viewPagerCardsButton = (Button) findViewById(R.id.tag_received_cards_viewpager);
        this.viewPagerResumesButton = (Button) findViewById(R.id.tag_received_resumes_viewpager);

        this.tag_received_save_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        this.viewPagerCardsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                viewPagerCard();
            }
        });
        this.viewPagerResumesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewPagerResume();
            }
        });
    }

    private void prepareCard()
    {
        this.intentCard = new businessCardItem();
        //set card name, remove the name from the string
        this.intentCard.setCardName(this.cardString.substring(0, this.cardString.indexOf('`')));
        this.cardString = this.cardString.substring(this.cardString.indexOf("`") + 1);
        //set phone, update string
        this.intentCard.setCardPhone(this.cardString.substring(0, this.cardString.indexOf('`')));
        this.cardString = this.cardString.substring(this.cardString.indexOf("`") + 1);
        //set email, update string
        this.intentCard.setCardEmail(this.cardString.substring(0, this.cardString.indexOf('`')));
        this.cardString = this.cardString.substring(this.cardString.indexOf("`") + 1);
        //set experiences, update string
        this.intentCard.setCardExperiences(this.cardString.substring(0, this.cardString.indexOf('`')));
        this.cardString = this.cardString.substring(this.cardString.indexOf("`") + 1);
        //set tags, update string - string should be empty after this
        this.intentCard.setCardTags(this.cardString.substring(0, this.cardString.indexOf('`')));
        this.cardString = "";
    }

    private void prepareResume()
    {
        this.intentResume = new resumeItem();
        //set resume name, update string
        this.intentResume.setResumeName(this.resumeString.substring(0, this.resumeString.indexOf("`")));
        this.resumeString = this.resumeString.substring(this.resumeString.indexOf("`") + 1);
        //set resume employment, update string
        this.intentResume.setResumeEmployment(this.resumeString.substring(0, this.resumeString.indexOf("`")));
        this.resumeString = this.resumeString.substring(this.resumeString.indexOf("`") + 1);
        //set resume location, update string
        this.intentResume.setResumeLivingLocation(this.resumeString.substring(0, this.resumeString.indexOf("`")));
        this.resumeString = this.resumeString.substring(this.resumeString.indexOf("`") + 1);
        //set resume biography, update string
        this.intentResume.setResumeBiography(this.resumeString.substring(0, this.resumeString.indexOf("`")));
        this.resumeString = this.resumeString.substring(this.resumeString.indexOf("`") + 1);
        //set resume experiences, update string
        this.intentResume.setResumeExperiences(this.resumeString.substring(0, this.resumeString.indexOf("`")));
        this.resumeString = this.resumeString.substring(this.resumeString.indexOf("`") + 1);
        //set resume educations, update string
        this.intentResume.setResumeEducations(this.resumeString.substring(0, this.resumeString.indexOf("`")));
        this.resumeString = "";
    }

    private void viewPagerCard() {
        this.fm = getSupportFragmentManager();
        tag_received_viewpager.setAdapter(new FragmentStatePagerAdapter(this.fm) {
            private cardFragment card_fragment;

            @Override
            public Fragment getItem(int position) {
                businessCardItem card = bCards.get(position);
                this.card_fragment = cardFragment.newInstance(card.getCardID());
                //cardFragment.removeViews(this.card_fragment);
                this.card_fragment = cardFragment.removeViews(this.card_fragment);
                return card_fragment;
            }

            @Override
            public int getCount() {
                return bCards.size();
            }
        });
        for (int i = 0; i < bCards.size(); i++) {
            if (bCards.get(i).getCardID().equals(intentCard.getCardID())) {
                tag_received_viewpager.setCurrentItem(i);
                break;
            }
        }
    }

    private void viewPagerResume() {
        this.rItems = resumeDbConnection.getDbConnection(this).getResumeItems();
        this.fm = getSupportFragmentManager();
        this.tag_received_viewpager.setAdapter(new FragmentStatePagerAdapter(fm) {
            @Override
            public Fragment getItem(int position) {
                resumeItem resume = rItems.get(position);
                return resumeFragment.newInstance(resume.getResumeUUID());
            }
            @Override
            public int getCount() {
                return rItems.size();
            }
        });
        for (int i = 0; i < rItems.size(); i++) {
            if (rItems.get(i).getResumeUUID().equals(intentResume.getResumeUUID())) {
                tag_received_viewpager.setCurrentItem(i);
                break;
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // Check to see that the Activity started due to an Android Beam
        if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(getIntent().getAction())) {
            processIntent(getIntent());
            //Toast.makeText(getApplicationContext(),"Success6",Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onNewIntent(Intent intent) {
        // onResume gets called after this to handle the intent
        setIntent(intent);
    }
    /**
     * Parses the NDEF Message from the intent and prints to the TextView
     */
    private void processIntent(Intent intent) {
        /*  check for duplicate card in database
        get db connection
        get existing cards
        check for matching name
        if name matches, check other fields
        if duplicate exists - output message - card already saved
        if not - display card/resume with option to save both
        will require a new interface  */
        Parcelable[] rawMsgs = intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
        NdefMessage msg = (NdefMessage) rawMsgs[0];
        this.cardString = new String(msg.getRecords()[0].getPayload());
        this.resumeString = new String(msg.getRecords()[2].getPayload());
        // record 0 contains the MIME type, record 1 is the AAR, if present
        //textView.setText(new String(msg.getRecords()[0].getPayload()));

        //Build the card and resume transferred over NFC, add to database
        prepareCard();
        cardDbConnection.getDbConnection(this).addCard(this.intentCard);
        prepareResume();
        resumeDbConnection.getDbConnection(this).addResume(this.intentResume);

        this.bCards = cardDbConnection.getDbConnection(this).getBusinessCards();
        this.rItems = resumeDbConnection.getDbConnection(this).getResumeItems();

        //initialize and page a card fragment
        this.fm = getSupportFragmentManager();
        tag_received_viewpager.setAdapter(new FragmentStatePagerAdapter(this.fm) {
            private cardFragment card_fragment;

            @Override
            public Fragment getItem(int position) {
                businessCardItem card = bCards.get(position);
                this.card_fragment = cardFragment.newInstance(card.getCardID());
                //cardFragment.removeViews(this.card_fragment);
                this.card_fragment = cardFragment.removeViews(this.card_fragment);
                return card_fragment;
            }

            @Override
            public int getCount() {
                return bCards.size();
            }
        });

        for (int i = 0; i < bCards.size(); i++) {
            if (bCards.get(i).getCardID().equals(intentCard.getCardID())) {
                tag_received_viewpager.setCurrentItem(i);
                break;
            }
        }

        //compare the constructed card to existing cards - see if a match is found
        boolean flag = true;
        for (int i = 0; i < bCards.size() && flag; i++) {
            if (intentCard.getCardName().equals(bCards.get(i).getCardName())) {
                if (intentCard.equals(bCards.get(i))) {
                    flag = false;
                }
            }
        }
        if (flag) {
            /*a match has not been found
                - display the card to user and offer saving
             */
            Toast.makeText(getApplicationContext(), "Success1", Toast.LENGTH_LONG).show();
        } else {
            /*a match has been found
                - this information already exists in the database
                - display the card to the user
                - (in place of save button) inform user card is already saved
             */
            Toast.makeText(getApplicationContext(), "Success0", Toast.LENGTH_LONG).show();
        }
    }
}