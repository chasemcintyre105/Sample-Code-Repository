package com.example.chase.termproject;

import android.content.Intent;
import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    private Button my_card_button;
    private Button my_resume_button;
    private Button new_card_button;
    private Button new_resume_button;
    private Button database_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.my_card_button = (Button) findViewById(R.id.main_activity_myCard_button);
        this.my_resume_button = (Button) findViewById(R.id.main_activity_myResume_button);
        this.new_card_button = (Button) findViewById(R.id.main_activity_newCard_button);
        this.new_resume_button = (Button) findViewById(R.id.main_activity_newResume_button);
        this.database_button = (Button) findViewById(R.id.main_activity_database_button);

        this.my_card_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UUID myUUID = new UUID(1,1);
                businessCardItem bCard = cardDbConnection.getDbConnection(getBaseContext()).getCard(myUUID);
                if(bCard == null)
                {
                    bCard = new businessCardItem(myUUID);
                    cardDbConnection.getDbConnection(getBaseContext()).addCard(bCard);
                }
                Intent intent = cardPagerActivity.newIntent(getBaseContext(), bCard.getCardID());
                startActivity(intent);
            }
        });

        this.new_card_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                businessCardItem bCard = new businessCardItem();
                cardDbConnection.getDbConnection(getBaseContext()).addCard(bCard);
                Intent intent = cardPagerActivity.newIntent(getBaseContext(), bCard.getCardID());
                intent.putExtra("flag", true);
                startActivity(intent);
            }
        });
        this.my_resume_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UUID myUUID = new UUID(1,1);
                resumeItem rItem = resumeDbConnection.getDbConnection(getBaseContext()).getResume(myUUID);
                if(rItem == null)
                {
                    rItem = new resumeItem(myUUID);
                    resumeDbConnection.getDbConnection(getBaseContext()).addResume(rItem);
                }
                Intent intent = resumePagerActivity.newIntent(getBaseContext(), rItem.getResumeUUID());
                intent.putExtra("flag", true);
                startActivity(intent);
            }
        });
        this.new_resume_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                resumeItem rItem = new resumeItem();
//                resumeDbConnection.getDbConnection(getBaseContext()).addResume(rItem);
//                Intent intent = resumePagerActivity.newIntent(getBaseContext(), rItem.getResumeUUID());
//                intent.putExtra("flag", true);
                Intent intent = new Intent(getBaseContext(), tag_sending.class);
                startActivity(intent);
            }
        });
        this.database_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), cardListActivity.class);
                startActivity(intent);
            }
        });
    }
}
