package com.example.chase.termproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.LinearLayoutManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import android.support.v4.app.Fragment;

public class resumeFragmentList extends Fragment {

    private RecyclerView resumeRecycerView;
    private Button cardButton;
    private Button resumeButton;
    private resumeAdapter rAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        View view = inflater.inflate(R.layout.resume_fragment_list, container, false);
        resumeRecycerView = (RecyclerView) view.findViewById(R.id.card_recycler_view);
        resumeRecycerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        this.cardButton = (Button) view.findViewById(R.id.card_button);
        this.resumeButton = (Button) view.findViewById(R.id.resume_button);

        this.cardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), cardListActivity.class);
                startActivity(intent);
            }
        });

        updateUI();
        return view;
    }

    private class ResumeHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private resumeItem rItem;
        private EditText resume_name_textView;
        private EditText resume_currentEmployment_textView;
        private EditText resume_livingLocation_textView;
        private EditText resume_biography_textView;
        private EditText resume_experience_positionTitle;
        private EditText resume_experience_employerInformation;
        private EditText resume_experience_jobDuties;
        private EditText resume_education_facility;
        private EditText resume_education_degree;
        private Button resume_experience_menuLeft_Button;
        private Button resume_experience_menuRight_Button;
        private Button resume_education_menuLeft_Button;
        private Button resume_education_menuRight_Button;

        private String resume_experiences;
        private String resume_educations;
        private int indexOf;

        public ResumeHolder(LayoutInflater inflater, ViewGroup parent) {

            super(inflater.inflate(R.layout.resume_view, parent, false));
            itemView.setOnClickListener(this);

            this.resume_name_textView = (EditText) itemView.findViewById(R.id.resume_name_textView);
            this.resume_name_textView.setInputType(0);
            //
            this.resume_currentEmployment_textView = (EditText) itemView.findViewById(R.id.resume_currentEmployment_textView);
            this.resume_currentEmployment_textView.setInputType(0);
            //
            this.resume_livingLocation_textView = (EditText) itemView.findViewById(R.id.resume_livingLocation_textView);
            this.resume_livingLocation_textView.setInputType(0);
            //
            this.resume_biography_textView = (EditText) itemView.findViewById(R.id.resume_biography_textView);
            this.resume_biography_textView.setInputType(0);
            //
            this.resume_experience_positionTitle = (EditText) itemView.findViewById(R.id.resume_experience_positionTitle);
            this.resume_experience_employerInformation = (EditText) itemView.findViewById(R.id.resume_experience_employerInformation);
            this.resume_experience_jobDuties = (EditText) itemView.findViewById(R.id.resume_experience_jobDuties);
            this.resume_experience_positionTitle.setInputType(0);
            this.resume_experience_employerInformation.setInputType(0);
            this.resume_experience_jobDuties.setInputType(0);
            //
            this.resume_education_degree = (EditText) itemView.findViewById(R.id.resume_education_degree);
            this.resume_education_facility = (EditText) itemView.findViewById(R.id.resume_education_facility);
            this.resume_education_degree.setInputType(0);
            this.resume_education_facility.setInputType(0);
            //
            this.resume_experience_menuLeft_Button = (Button) itemView.findViewById(R.id.resume_experience_menuLeft_button);
            this.resume_experience_menuRight_Button = (Button) itemView.findViewById(R.id.resume_experience_menuRight_button);
            this.resume_education_menuLeft_Button = (Button) itemView.findViewById(R.id.resume_education_menuLeft_button);
            this.resume_education_menuRight_Button = (Button) itemView.findViewById(R.id.resume_education_menuRight_button);
        }

        public void bind(resumeItem rItem) {
            this.rItem = rItem;
            this.resume_name_textView.setText(rItem.getResumeName());
            this.resume_currentEmployment_textView.setText(rItem.getResumeEmployment());
            this.resume_livingLocation_textView.setText(rItem.getResumeLivingLocation());
            this.resume_biography_textView.setText(rItem.getResumeBiography());

            setExperience();
            setEducation();
        }

        @Override
        public void onClick(View view) {
            Intent intent = resumePagerActivity.newIntent(getActivity(), rItem.getResumeUUID());
            intent.putExtra("flag", false);
            startActivity(intent);
        }

        public void setEducation()
        {
            this.resume_educations = this.rItem.getResumeEducations();
            //parse and set
            if(this.resume_educations.indexOf('_') != -1)
            {
                this.indexOf = this.resume_educations.indexOf('^');
                if(this.indexOf != -1)
                {
                    this.resume_education_degree.setText(this.resume_educations.substring(0, this.indexOf));
                    this.resume_education_facility.setText(this.resume_educations.substring(this.indexOf + 1));
                }
            }
        }

        public void setExperience()
        {
            this.resume_experiences = this.rItem.getResumeExperiences();
            if(this.resume_experiences.indexOf('_') != -1)
            {
                this.indexOf = this.resume_experiences.indexOf('^');
                if(this.indexOf != -1)
                {
                    //set position title, then parse for employer information
                    this.resume_experience_positionTitle.setText(this.resume_experiences.substring(0, this.indexOf));
                    this.resume_experiences = this.resume_experiences.substring(this.indexOf+1);

                    this.indexOf = this.resume_experiences.indexOf('^');
                    if(this.indexOf != -1)
                    {
                        this.resume_experience_employerInformation.setText(this.resume_experiences.substring(0, this.indexOf));
                        this.resume_experiences = this.resume_experiences.substring(this.indexOf+1);

                        if(this.resume_experiences.indexOf('^') != -1)
                        {
                            this.resume_experience_jobDuties.setText(this.resume_experiences);
                        }
                    }
                }

            }
        }
    }


    private class resumeAdapter extends RecyclerView.Adapter<ResumeHolder>
    {
        private List<resumeItem> rItems;
        public resumeAdapter(List<resumeItem> resumes)
        {
            this.rItems = resumes;
        }

        @Override
        public ResumeHolder onCreateViewHolder(ViewGroup parent, int viewType)
        {
            LayoutInflater inflater = LayoutInflater.from(getActivity());
            return new resumeFragmentList.ResumeHolder(inflater, parent);
        }

        @Override
        public void onBindViewHolder(resumeFragmentList.ResumeHolder holder, int position)
        {
            resumeItem resume = this.rItems.get(position);
            holder.bind(resume);
        }

        @Override
        public int getItemCount()
        {
            return this.rItems.size();
        }

        public void setResumes(List<resumeItem> resumes)
        {
            this.rItems = resumes;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        updateUI();
    }

    private void updateUI()
    {
        resumeDbConnection rDBcon = resumeDbConnection.getDbConnection(getActivity());
        List<resumeItem> rItems = rDBcon.getResumeItems();

        if(this.rAdapter == null)
        {
            this.rAdapter = new resumeAdapter(rItems);
            this.resumeRecycerView.setAdapter(rAdapter);
        }
        else
        {
            this.rAdapter.setResumes(rItems);
            this.rAdapter.notifyDataSetChanged();
        }
    }
}
