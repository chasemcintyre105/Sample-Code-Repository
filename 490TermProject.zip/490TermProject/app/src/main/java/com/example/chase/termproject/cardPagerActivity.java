package com.example.chase.termproject;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;

import java.util.List;
import java.util.UUID;

public class cardPagerActivity extends AppCompatActivity {

    private static final String EXTRA_CARD_ID = "com.example.chase.TermProject.card_id";
    private ViewPager cViewPager;
    private List<businessCardItem> bCards;

    public static Intent newIntent(Context context, UUID cardID)
    {
        Intent intent = new Intent(context,  cardPagerActivity.class);
        intent.putExtra(EXTRA_CARD_ID, cardID);
        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_pager);

        UUID cardID = (UUID) getIntent().getSerializableExtra(EXTRA_CARD_ID);
        cViewPager = (ViewPager) findViewById(R.id.card_view_pager);
        bCards = cardDbConnection.getDbConnection(this).getBusinessCards();
        FragmentManager fm = getSupportFragmentManager();
        cViewPager.setAdapter(new FragmentStatePagerAdapter(fm) {
            @Override
            public Fragment getItem(int position) {
                businessCardItem card = bCards.get(position);
                return cardFragment.newInstance(card.getCardID());
            }
            @Override
            public int getCount() {
                return bCards.size();
            }
        });

        for(int i = 0; i < bCards.size(); i++)
        {
            if(bCards.get(i).getCardID().equals(cardID))
            {
                cViewPager.setCurrentItem(i);
                break;
            }
        }

    }
}
