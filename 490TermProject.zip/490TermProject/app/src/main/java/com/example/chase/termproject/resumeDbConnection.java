package com.example.chase.termproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


import com.example.chase.termproject.Database.NearFieldNetworkingDbSchema;
import com.example.chase.termproject.Database.NFNCursorWrapper;
import com.example.chase.termproject.Database.NFNBaseHelper;

public class resumeDbConnection
{
    private static resumeDbConnection thisCardDbConnection;
    private Context context;
    private SQLiteDatabase DB;

    public static resumeDbConnection getDbConnection(Context context)
    {
        if(thisCardDbConnection == null)
        {
            thisCardDbConnection = new resumeDbConnection(context);
        }
        return thisCardDbConnection;
    }

    private resumeDbConnection(Context context)
    {
        this.context = context;
        this.DB = new NFNBaseHelper(this.context).getWritableDatabase();
    }

    public void addResume(resumeItem rItem)
    {
        ContentValues values = getContentValues(rItem);
        DB.insert(NearFieldNetworkingDbSchema.ResumeTable.RESUMENAME, null, values);
    }

    public void deleteResume(resumeItem rItem)
    {
        DB.delete(NearFieldNetworkingDbSchema.ResumeTable.RESUMENAME,
                NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.UUID + " = ?", new String[] {rItem.getResumeUUID().toString()}
                );
    }

    public List<resumeItem> getResumeItems()
    {
        List<resumeItem> resumes = new ArrayList<resumeItem>();
        NFNCursorWrapper cursor = queryResumes(null, null);

        try
        {
            cursor.moveToFirst();
            while(!cursor.isAfterLast())
            {
                resumes.add(cursor.getResume());
                cursor.moveToNext();
            }
        }
        finally
        {
            cursor.close();
        }
        return resumes;
    }

    public void updateResume(resumeItem rItem)
    {
        String UUIDString = rItem.getResumeUUID().toString();
        ContentValues values = getContentValues(rItem);

        DB.update(NearFieldNetworkingDbSchema.ResumeTable.RESUMENAME, values, NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.UUID
                + " = ?", new String[]{UUIDString});
    }

    public resumeItem getResume(UUID rID)
    {
        NFNCursorWrapper cursor = queryResumes(NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.UUID + " = ?",
                new String[]{rID.toString()});
        try
        {
            if(cursor.getCount() == 0)
            {
                return null;
            }
            cursor.moveToFirst();
            return cursor.getResume();
        }
        finally
        {
            cursor.close();
        }
    }

    private NFNCursorWrapper queryResumes(String whereClause, String[] whereArgs) {
        Cursor cursor = DB.query(
                NearFieldNetworkingDbSchema.ResumeTable.RESUMENAME,
                null, whereClause, whereArgs,null, null, null);

        return new NFNCursorWrapper(cursor);
    }
    private static ContentValues getContentValues(resumeItem rCard) {
        ContentValues values = new ContentValues();
        values.put(NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.UUID, rCard.getResumeUUID().toString());
        values.put(NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.RESUMENAME, rCard.getResumeName());
        values.put(NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.RESUMECURRENTEMPLOYMENT, rCard.getResumeEmployment());
        values.put(NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.RESUMELIVINGLOCATION, rCard.getResumeLivingLocation());
        values.put(NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.RESUMEBIOGRAPHY, rCard.getResumeBiography());
        values.put(NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.RESUMEEXPERIENCE, rCard.getResumeExperiences());
        values.put(NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.RESUMEEDUCATION, rCard.getResumeEducations());
        return values;
    }
}
