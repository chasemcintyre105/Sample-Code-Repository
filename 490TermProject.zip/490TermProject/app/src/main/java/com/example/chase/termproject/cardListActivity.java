package com.example.chase.termproject;

import android.support.v4.app.Fragment;

public class cardListActivity extends SingleFragmentActivity {

    @Override
    protected Fragment createFragment()
    {
        return new cardFragmentList();
    }

}
