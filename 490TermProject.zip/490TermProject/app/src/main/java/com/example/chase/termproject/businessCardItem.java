package com.example.chase.termproject;

import java.util.UUID;

public class businessCardItem {

    private UUID cardUUID;
    private String cardName;
    private String cardPhone;
    private String cardEmail;
    private String cardExperiences;
    private String cardTags;

    public businessCardItem()
    {
        this(UUID.randomUUID());
        setCardName("");
        setCardPhone("");
        setCardEmail("");
        setCardExperiences("");
        setCardTags("");
    }
    public businessCardItem(UUID id)
    {
        cardUUID = id;
        setCardName("");
        setCardPhone("");
        setCardEmail("");
        setCardExperiences("");
        setCardTags("");
    }

    public UUID getCardID()
    {
        return this.cardUUID;
    }
    public String getCardName()
    {
        return this.cardName;
    }
    public String getCardPhone()
    {
        return this.cardPhone;
    }
    public String getCardEmail()
    {
        return this.cardEmail;
    }
    public String getCardExperiences()
    {
        return this.cardExperiences;
    }
    public String getCardTags()
    {
        return this.cardTags;
    }

    public void setCardName(String newName)
    {
        this.cardName = newName;
    }
    public void setCardPhone(String newPhone)
    {
        this.cardPhone = newPhone;
    }
    public void setCardEmail(String newEmail)
    {
        this.cardEmail = newEmail;
    }
    public void setCardExperiences(String newExperiences)
    {
        this.cardExperiences = newExperiences;
    }
    public void setCardTags(String newTags)
    {
        this.cardTags = newTags;
    }

    public boolean equals(businessCardItem otherCard)
    {
        if( cardName.equals(otherCard.cardName) && cardPhone.equals(otherCard.cardPhone) && cardEmail.equals(otherCard.getCardEmail())
                && cardExperiences.equals(otherCard.getCardExperiences()) && cardTags.equals(otherCard.getCardTags()))
            return true;
        else
            return false;
    }
}
