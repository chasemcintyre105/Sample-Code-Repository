package com.example.chase.termproject;

import java.util.UUID;

public class resumeItem {

    private UUID resumeUUID;
    private String resumeName;
    private String resumeEmployment;
    private String resumeLivingLocation;
    private String resumeBiography;
    private String resumeExperiences;
    private String resumeEducations;

    public resumeItem()
    {
        this(UUID.randomUUID());
        setResumeName("");
        setResumeEmployment("");
        setResumeLivingLocation("");
        setResumeBiography("");
        setResumeExperiences("");
        setResumeEducations("");
    }
    public resumeItem(UUID id)
    {
        this.resumeUUID = id;
        setResumeName("");
        setResumeEmployment("");
        setResumeLivingLocation("");
        setResumeBiography("");
        setResumeExperiences("");
        setResumeEducations("");
    }

    public UUID getResumeUUID()
    {
        return this.resumeUUID;
    }
    public String getResumeName()
    {
        return this.resumeName;
    }
    public String getResumeEmployment()
    {
        return this.resumeEmployment;
    }
    public String getResumeLivingLocation()
    {
        return this.resumeLivingLocation;
    }
    public String getResumeBiography()
    {
        return this.resumeBiography;
    }
    public String getResumeExperiences()
    {
        return this.resumeExperiences;
    }
    public String getResumeEducations()
    {
        return this.resumeEducations;
    }

    public void setResumeName(String newName)
    {
        this.resumeName = newName;
    }
    public void setResumeEmployment(String newEmployment)
    {
        this.resumeEmployment = newEmployment;
    }
    public void setResumeLivingLocation(String newLivingLocation)
    {
        this.resumeLivingLocation = newLivingLocation;
    }
    public void setResumeBiography(String newBiography)
    {
        this.resumeBiography = newBiography;
    }
    public void setResumeExperiences(String newExperiences)
    {
        this.resumeExperiences = newExperiences;
    }
    public void setResumeEducations(String newEducations)
    {
        this.resumeEducations = newEducations;
    }


}
