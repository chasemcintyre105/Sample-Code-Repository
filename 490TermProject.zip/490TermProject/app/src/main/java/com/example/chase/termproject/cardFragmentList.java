package com.example.chase.termproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.LinearLayoutManager;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;


public class cardFragmentList extends Fragment {

    private RecyclerView cardRecycerView;
    private Button cardButton;
    private Button resumeButton;
    private cardAdapter cAdapter;
    private NavigationView cards_navigation_view;
    private EditText cards_toolbar_edittext;
    private DrawerLayout cards_drawer_layout;
    private Toolbar cards_toolbar;
    private ImageButton cards_search_button;
    private ImageView cards_toolbar_menuImage;

    private List<businessCardItem> bCards;
    private List<businessCardItem> tempBCards;
    private int filterFlags;
    private int previousFilterFlags;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.card_fragment_list, container, false);

        bCards = cardDbConnection.getDbConnection(getActivity()).getBusinessCards();

        this.cardRecycerView = (RecyclerView) view.findViewById(R.id.card_recycler_view);
        this.cardRecycerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        this.cardButton = (Button) view.findViewById(R.id.card_button);
        this.resumeButton = (Button) view.findViewById(R.id.resume_button);

        this.resumeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), resumeListActivity.class);
                startActivity(intent);
            }
        });

        this.cards_search_button = (ImageButton) view.findViewById(R.id.cards_toolbar_search_button);
        this.cards_toolbar_edittext = (EditText) view.findViewById(R.id.cards_toolbar_textview);
        this.cards_drawer_layout = (DrawerLayout) view.findViewById(R.id.cards_drawer_layout);
        this.cards_navigation_view = (NavigationView) view.findViewById(R.id.cards_navigation_view);

        this.cards_navigation_view.getMenu().setGroupCheckable(R.id.cards_menu_group, true, false);
        this.cards_toolbar = view.findViewById(R.id.cards_toolbar);

        this.cards_toolbar_menuImage = (ImageView) view.findViewById(R.id.cards_toolbar_menuImage);
        this.cards_toolbar_menuImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cards_drawer_layout.openDrawer(GravityCompat.START);
            }
        });

        cards_navigation_view.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        if (item.getItemId() == R.id.cards_nav_name) {
                            item.setIcon(R.drawable.check_box_on);
                            cards_navigation_view.getMenu().getItem(1).setIcon(R.drawable.check_box_off);
                            cards_navigation_view.getMenu().getItem(2).setIcon(R.drawable.check_box_off);
                            filterFlags = 1;
                        } else if (item.getItemId() == R.id.cards_nav_phone) {
                            item.setIcon(R.drawable.check_box_on);
                            cards_navigation_view.getMenu().getItem(0).setIcon(R.drawable.check_box_off);
                            cards_navigation_view.getMenu().getItem(2).setIcon(R.drawable.check_box_off);
                            filterFlags = 2;
                        } else if (item.getItemId() == R.id.cards_nav_email) {
                            item.setIcon(R.drawable.check_box_on);
                            cards_navigation_view.getMenu().getItem(0).setIcon(R.drawable.check_box_off);
                            cards_navigation_view.getMenu().getItem(1).setIcon(R.drawable.check_box_off);
                            filterFlags = 4;
                        } else if (item.getItemId() == R.id.cards_nav_apply) {
                            filterResults();
                            cards_drawer_layout.closeDrawers();
                        } else if (item.getItemId() == R.id.cards_nav_clear) {
                            for (int i = 0; i < cards_navigation_view.getMenu().size() - 2; i++) {
                                cards_navigation_view.getMenu().getItem(i).setIcon(R.drawable.check_box_off);
                            }
                            filterFlags = 0;
                            filterResults();
                            cards_drawer_layout.closeDrawers();
                        }
                        return true;
                    }
                });

        this.cards_search_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchCardsForString(cards_toolbar_edittext.getText().toString());
            }
        });

        updateUI();
        return view;
    }

    private void searchCardsForString(String key) {
        if (key.length() > 0) {
            List<businessCardItem> tempCards = new ArrayList<>();
            if (tempBCards == null) {
                for (int i = 0; i < bCards.size(); i++) {
                    if (searchCardForKey(key, bCards.get(i)) == 1) {
                        tempCards.add(bCards.get(i));
                    }
                }
            } else {
                for (int i = 0; i < tempBCards.size(); i++) {
                    if (searchCardForKey(key, tempBCards.get(i)) == 1) {
                        tempCards.add(tempBCards.get(i));
                    }
                }
            }
            tempBCards = tempCards;
        } else {
            tempBCards = bCards;
        }
        updateUI();
    }

    private int searchCardForKey(String key, businessCardItem card) {
        if (card.getCardName().contains(key)) {
            return 1;
        } else if (card.getCardEmail().contains(key)) {
            return 1;
        } else if (card.getCardPhone().contains(key)) {
            return 1;
        } else if (card.getCardTags().contains(key)) {
            return 1;
        } else if (card.getCardExperiences().contains(key)) {
            return 1;
        }
        return 0;
    }

    private void filterResults() {
        previousFilterFlags = filterFlags;

        if (filterFlags == 0) {
            tempBCards = bCards;
        } else {
            tempBCards = new ArrayList<>();
            tempBCards.addAll(bCards);

            if (filterFlags == 1) {
                //by name
                ArrayList<String> nameList = new ArrayList<>();
                for (int i = 0; i < tempBCards.size(); i++) {
                    nameList.add(tempBCards.get(i).getCardName());
                }
                tempBCards.clear();
                Collections.sort(nameList, String.CASE_INSENSITIVE_ORDER);
                for (int i = 0; i < nameList.size(); i++) {
                    for (int z = 0; z < bCards.size(); z++) {
                        if (nameList.get(i).compareTo(bCards.get(z).getCardName()) == 0) {
                            tempBCards.add(bCards.get(z));
                            z = bCards.size();
                        }
                    }
                }
            } else if (filterFlags == 2) {
                //by phone
                ArrayList<String> phoneList = new ArrayList<>();
                for (int i = 0; i < tempBCards.size(); i++) {
                    phoneList.add(tempBCards.get(i).getCardPhone());
                }
                tempBCards.clear();
                Collections.sort(phoneList, String.CASE_INSENSITIVE_ORDER);
                for (int i = 0; i < phoneList.size(); i++) {
                    for (int z = 0; z < bCards.size(); z++) {
                        if (phoneList.get(i).compareTo(bCards.get(z).getCardPhone()) == 0) {
                            tempBCards.add(bCards.get(z));
                            z = bCards.size();
                        }
                    }
                }
            } else if (filterFlags == 4) {
                //by email
                ArrayList<String> emailList = new ArrayList<>();
                for (int i = 0; i < tempBCards.size(); i++) {
                    emailList.add(tempBCards.get(i).getCardEmail());
                }
                tempBCards.clear();
                Collections.sort(emailList, String.CASE_INSENSITIVE_ORDER);
                for (int i = 0; i < emailList.size(); i++) {
                    for (int z = 0; z < bCards.size(); z++) {
                        if (emailList.get(i).compareTo(bCards.get(z).getCardEmail()) == 0) {
                            tempBCards.add(bCards.get(z));
                            z = bCards.size();
                        }
                    }
                }
            }
        }
        updateUI();
    }


//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
//            case android.R.id.home:
//                int tempInt = 0;
//                if(previousFilterFlags != filterFlags)
//                {
//                    filterFlags = previousFilterFlags;
//                    for(int i = 1; i < 16; i = i*2)
//                    {
//                        for(int j = 0; j < this.results_navigation_view.getMenu().size()-2; j++)
//                        {
//                            if(Math.pow(2,tempInt) == i)
//                            {
//                                break;
//                            }
//                            tempInt++;
//                        }
//
//                        if( (filterFlags & i) == 0)
//                        {
//                            this.results_navigation_view.getMenu().getItem(tempInt).setIcon(R.drawable.check_box_off);
//                        }
//                        else
//                        {
//                            this.results_navigation_view.getMenu().getItem(tempInt).setIcon(R.drawable.check_box_on);
//                        }
//                    }
//                }
//                this.cards_drawer_layout.openDrawer(GravityCompat.START);
//                return true;
//        }
//        return super.onOptionsItemSelected(item);
//    }

    private class CardHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private businessCardItem bCard;
        private EditText nameEditText;
        private EditText phoneEditText;
        private EditText emailEditText;
        private TextView experienceView0;
        private TextView experienceView1;
        private TextView tagView0;
        private TextView tagView1;
        private TextView tagView2;
        private TextView tagView3;
        private Button menuLeft;
        private Button menuRight;

        private int i = 0;
        private int j = 0;
        private View experience_view;
        private TextView temp_textview;

        public CardHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.business_card_view, parent, false));
            itemView.setOnClickListener(this);
            this.nameEditText = (EditText) itemView.findViewById(R.id.business_card_userName_edittext);
            this.phoneEditText = (EditText) itemView.findViewById(R.id.business_card_phoneNumber_edittext);
            this.emailEditText = (EditText) itemView.findViewById(R.id.business_card_emailAddress_edittext);

            experience_view = (View) itemView.findViewById(R.id.business_card_experience_view1);
            ViewGroup parent2 = (ViewGroup) experience_view.getParent();
            int index = parent2.indexOfChild(experience_view);

            //Experiences
            float layoutWeight = (float) .50;
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 60);
            layoutParams.weight = layoutWeight;
            layoutParams.gravity = Gravity.CENTER;
            //Experience 1
            temp_textview = new TextView(getContext());
            temp_textview.setId(j);
            j++;
            //temp_textview.setHint(R.string.add_job_experience);
            temp_textview.setGravity(Gravity.CENTER);
            temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            temp_textview.setLayoutParams(layoutParams);
            temp_textview.setTextSize(12);
            parent2.removeViewAt(index);
            parent2.addView(temp_textview, index);
            //Experience 2
            experience_view = (View) itemView.findViewById(R.id.business_card_experience_view2);
            parent2 = (ViewGroup) experience_view.getParent();
            index = parent2.indexOfChild(experience_view);
            temp_textview = new TextView(getContext());
            temp_textview.setId(j);
            j++;
            //temp_textview.setHint(R.string.add_job_experience);
            temp_textview.setGravity(Gravity.CENTER);
            temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            temp_textview.setLayoutParams(layoutParams);
            temp_textview.setTextSize(12);
            parent2.removeViewAt(index);
            parent2.addView(temp_textview, index);
            temp_textview.setInputType(0);

            this.i = 0;
            //Tags
            layoutWeight = (float) 45;
            layoutParams = new LinearLayout.LayoutParams(0, 80);
            layoutParams.weight = layoutWeight;
            layoutParams.gravity = Gravity.START;
            layoutParams.topMargin = 10;
            //Tag 1
            experience_view = (View) itemView.findViewById(R.id.business_card_tag_view1);
            parent2 = (ViewGroup) experience_view.getParent();
            index = parent2.indexOfChild(experience_view);
            temp_textview = new TextView(getContext());
            temp_textview.setId(j);
            j++;
            //temp_textview.setHint(R.string.enter_skill_tag);
            temp_textview.setGravity(Gravity.CENTER);
            temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            temp_textview.setLayoutParams(layoutParams);
            temp_textview.setTextSize(12);
            parent2.removeViewAt(index);
            parent2.addView(temp_textview, index);
            temp_textview.setInputType(0);
            //Tag 2
            experience_view = (View) itemView.findViewById(R.id.business_card_tag_view2);
            parent2 = (ViewGroup) experience_view.getParent();
            index = parent2.indexOfChild(experience_view);
            temp_textview = new TextView(getContext());
            temp_textview.setId(j);
            j++;
            //temp_textview.setHint(R.string.enter_skill_tag);
            temp_textview.setGravity(Gravity.CENTER);
            temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            temp_textview.setLayoutParams(layoutParams);
            temp_textview.setTextSize(12);
            parent2.removeViewAt(index);
            parent2.addView(temp_textview, index);
            //Tag 3
            experience_view = (View) itemView.findViewById(R.id.business_card_tag_view3);
            parent2 = (ViewGroup) experience_view.getParent();
            index = parent2.indexOfChild(experience_view);
            temp_textview = new TextView(getContext());
            temp_textview.setId(j);
            j++;
            //temp_textview.setHint(R.string.enter_skill_tag);
            temp_textview.setGravity(Gravity.CENTER);
            temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            temp_textview.setLayoutParams(layoutParams);
            temp_textview.setTextSize(12);
            parent2.removeViewAt(index);
            parent2.addView(temp_textview, index);
            //Tag 4
            experience_view = (View) itemView.findViewById(R.id.business_card_tag_view4);
            parent2 = (ViewGroup) experience_view.getParent();
            index = parent2.indexOfChild(experience_view);
            temp_textview = new TextView(getContext());
            temp_textview.setId(j);
            j++;
            //temp_textview.setHint(R.string.enter_skill_tag);
            temp_textview.setGravity(Gravity.CENTER);
            temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            temp_textview.setLayoutParams(layoutParams);
            temp_textview.setTextSize(12);
            parent2.removeViewAt(index);
            parent2.addView(temp_textview, index);

            j = 0;
            this.experienceView0 = itemView.findViewById(j);
            j++;
            this.experienceView1 = itemView.findViewById(j);
            j++;
            this.tagView0 = itemView.findViewById(j);
            j++;
            this.tagView1 = itemView.findViewById(j);
            j++;
            this.tagView2 = itemView.findViewById(j);
            j++;
            this.tagView3 = itemView.findViewById(j);
            j++;

            this.emailEditText.setInputType(0);
            this.phoneEditText.setInputType(0);
            this.nameEditText.setInputType(0);
            this.experienceView0.setInputType(0);
            this.experienceView1.setInputType(0);
            this.tagView0.setInputType(0);
            this.tagView1.setInputType(0);
            this.tagView2.setInputType(0);
            this.tagView3.setInputType(0);

            this.menuLeft = itemView.findViewById(R.id.business_card_menuLeft_button);
            this.menuRight = itemView.findViewById(R.id.business_card_menuRight_button);


        }

        public void bind(businessCardItem bCard) {
            this.bCard = bCard;
            this.nameEditText.setText(bCard.getCardName());
            this.phoneEditText.setText(bCard.getCardPhone());
            this.emailEditText.setText(bCard.getCardEmail());

            String experienceString = bCard.getCardExperiences();
            String tagsString = bCard.getCardTags();
            String tagsArray[] = new String[100];

            if (experienceString != null) {
                if (experienceString.contains("_")) {
                    if (experienceString.indexOf("_") + 1 == experienceString.length()) {
                        experienceView0.setText(experienceString);
                    } else {
                        experienceView0.setText(experienceString.substring(0, experienceString.indexOf("_")));
                        experienceView1.setText(experienceString.substring(experienceString.indexOf("_") + 1, experienceString.length() - 1));
                    }
                }
            }

            int x = 0;
            if (tagsString != null) {
                while (tagsString.contains("_")) {
                    tagsArray[x] = tagsString.substring(0, tagsString.indexOf("_"));
                    if (tagsString.indexOf("_") + 1 == tagsString.length()) {
                        tagsString = "";
                    } else {
                        tagsString = tagsString.substring(tagsString.indexOf("_") + 1);
                    }
                    x++;
                }
            }
            x = 0;
            this.tagView0.setText(tagsArray[x]);
            x++;
            this.tagView1.setText(tagsArray[x]);
            x++;
            this.tagView2.setText(tagsArray[x]);
            x++;
            this.tagView3.setText(tagsArray[x]);
            x++;

        }

        @Override
        public void onClick(View view) {
            Intent intent = cardPagerActivity.newIntent(getActivity(), bCard.getCardID());
            UUID testUUID = new UUID(1, 1);
            if (!bCard.getCardID().equals(testUUID)) {
                intent.putExtra("flag", false);
            }
            startActivity(intent);
        }
    }

    private class cardAdapter extends RecyclerView.Adapter<CardHolder> {
        private List<businessCardItem> bCards;

        public cardAdapter(List<businessCardItem> cards) {
            this.bCards = cards;
        }

        @Override
        public CardHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(getActivity());
            return new CardHolder(inflater, parent);
        }

        @Override
        public void onBindViewHolder(CardHolder holder, int position) {
            businessCardItem bCard = this.bCards.get(position);
            holder.bind(bCard);
        }

        @Override
        public int getItemCount() {
            return this.bCards.size();
        }

        public void setCards(List<businessCardItem> cards) {
            this.bCards = cards;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        updateUI();
    }

    private void updateUI() {
        if (tempBCards == null) {
            cardDbConnection cDBcon = cardDbConnection.getDbConnection(getActivity());
            bCards = cDBcon.getBusinessCards();

            if (this.cAdapter == null) {
                this.cAdapter = new cardAdapter(bCards);
                this.cardRecycerView.setAdapter(cAdapter);
            } else {
                this.cAdapter.setCards(bCards);
                this.cAdapter.notifyDataSetChanged();
            }
        } else {
            if (this.cAdapter == null) {
                this.cAdapter = new cardAdapter(tempBCards);
                this.cardRecycerView.setAdapter(cAdapter);
            } else {
                this.cAdapter.setCards(tempBCards);
                this.cAdapter.notifyDataSetChanged();
            }
        }
    }
}
