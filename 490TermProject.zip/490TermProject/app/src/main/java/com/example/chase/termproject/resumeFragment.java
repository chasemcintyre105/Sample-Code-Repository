package com.example.chase.termproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.UUID;

public class resumeFragment extends Fragment {

    private static final String ARG_RESUME_ID = "resume_id";
    private static final int REQUEST_DATE = 0;

    private resumeItem rItem;
    private EditText resume_name_textView;
    private EditText resume_currentEmployment_textView;
    private EditText resume_livingLocation_textView;
    private EditText resume_biography_textView;
    private EditText resume_experience_positionTitle;
    private EditText resume_experience_employerInformation;
    private EditText resume_experience_jobDuties;
    private EditText resume_education_facility;
    private EditText resume_education_degree;
    private Button resume_experience_menuLeft_Button;
    private Button resume_experience_menuRight_Button;
    private Button resume_education_menuLeft_Button;
    private Button resume_education_menuRight_Button;
    private String experienceString;
    private String educationString;
    private String experienceArray[];
    private String educationArray[];
    private int experienceCount;
    private int educationCount;
    private int experiencePage;
    private int educationPage;
    private int indexOf;

    private int i = 0;
    private int j = 0;
    private View experience_view;
    private TextView temp_textview;

    public static resumeFragment newInstance(UUID rID) {
        Bundle args = new Bundle();
        args.putSerializable(ARG_RESUME_ID, rID);

        resumeFragment fragment = new resumeFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        UUID rID = (UUID) getArguments().getSerializable(ARG_RESUME_ID);
        this.rItem = resumeDbConnection.getDbConnection(getActivity()).getResume(rID);
    }

    @Override
    public void onPause() {
        super.onPause();
        resumeDbConnection.getDbConnection(getActivity()).updateResume(this.rItem);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.delete_card_menu, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.delete_card:
                resumeDbConnection.getDbConnection(getActivity()).deleteResume(rItem);
                getActivity().finish();
                break;
            case R.id.email_send:
                StringBuilder emailBody = new StringBuilder();
                if (this.rItem.getResumeName().compareTo("") != 0) {
                    emailBody.append(this.rItem.getResumeName());
                    emailBody.append('\n');
                }
                if (this.rItem.getResumeEmployment().compareTo("") != 0) {
                    emailBody.append(this.rItem.getResumeEmployment());
                    emailBody.append('\n');
                }
                if (this.rItem.getResumeLivingLocation().compareTo("") != 0) {
                    emailBody.append(this.rItem.getResumeLivingLocation());
                    emailBody.append('\n');
                }
                if (this.rItem.getResumeBiography().compareTo("") != 0) {
                    emailBody.append(this.rItem.getResumeBiography());
                    emailBody.append('\n');
                }
                if (this.rItem.getResumeExperiences().compareTo("") != 0) {
                    emailBody.append(this.rItem.getResumeExperiences());
                    emailBody.append('\n');
                }
                if (this.rItem.getResumeEducations().compareTo("") != 0) {
                    emailBody.append(this.rItem.getResumeEducations());
                    emailBody.append('\n');
                }
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/html");
                intent.putExtra(Intent.EXTRA_TEXT, emailBody.toString());
                startActivity(Intent.createChooser(intent, "Send Email"));
                getActivity().finish();
                break;
            default:
                saveExperiences();
                getActivity().finish();
                return true;
        }
        return false;
    }

    public void saveExperiences() {
        StringBuilder experienceStringUpdate = new StringBuilder();
        for (int i = 0; i <= experienceCount; i++) {
            experienceStringUpdate.append(experienceArray[i]);
            experienceStringUpdate.append('^');
            if(i%3 == 2)
            {
                experienceStringUpdate.append('_');
            }
        }
        this.rItem.setResumeExperiences(experienceStringUpdate.toString());
//        Toast.makeText(getContext(), tagStringUpdate.toString(), Toast.LENGTH_LONG).show();
//        this.bCard.setCardTags(tagStringUpdate.toString());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.resume_view, container, false);

        this.resume_name_textView = (EditText) v.findViewById(R.id.resume_name_textView);
        this.resume_currentEmployment_textView = (EditText) v.findViewById(R.id.resume_currentEmployment_textView);
        this.resume_livingLocation_textView = (EditText) v.findViewById(R.id.resume_livingLocation_textView);
        this.resume_biography_textView = (EditText) v.findViewById(R.id.resume_biography_textView);
        this.resume_experience_positionTitle = (EditText) v.findViewById(R.id.resume_experience_positionTitle);
        this.resume_experience_employerInformation = (EditText) v.findViewById(R.id.resume_experience_employerInformation);
        this.resume_experience_jobDuties = (EditText) v.findViewById(R.id.resume_experience_jobDuties);
        this.resume_education_facility = (EditText) v.findViewById(R.id.resume_education_facility);
        this.resume_education_degree = (EditText) v.findViewById(R.id.resume_education_degree);
        this.resume_experience_menuLeft_Button = (Button) v.findViewById(R.id.resume_experience_menuLeft_button);
        this.resume_experience_menuRight_Button = (Button) v.findViewById(R.id.resume_experience_menuRight_button);
        this.resume_education_menuLeft_Button = (Button) v.findViewById(R.id.resume_education_menuLeft_button);
        this.resume_education_menuRight_Button = (Button) v.findViewById(R.id.resume_education_menuRight_button);

        Intent intent = getActivity().getIntent();
        if (!intent.getBooleanExtra("flag", true)) {
            UUID testUUID = new UUID(1, 1);
            if (!this.rItem.getResumeUUID().equals(testUUID)) {
                this.resume_name_textView.setInputType(0);
                this.resume_currentEmployment_textView.setInputType(0);
                this.resume_livingLocation_textView.setInputType(0);
                this.resume_biography_textView.setInputType(0);
                this.resume_experience_positionTitle.setInputType(0);
                this.resume_experience_employerInformation.setInputType(0);
                this.resume_experience_jobDuties.setInputType(0);
                this.resume_education_facility.setInputType(0);
                this.resume_education_degree.setInputType(0);
            }
        }

        this.resume_name_textView.setText(this.rItem.getResumeName());
        this.resume_name_textView.setHint(R.string.enter_name);
        this.resume_name_textView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                rItem.setResumeName(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        this.resume_currentEmployment_textView.setText(this.rItem.getResumeEmployment());
        this.resume_currentEmployment_textView.setHint(R.string.enter_current_job_and_location);
        this.resume_currentEmployment_textView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                rItem.setResumeEmployment(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        this.resume_livingLocation_textView.setText(this.rItem.getResumeLivingLocation());
        this.resume_livingLocation_textView.setHint(R.string.enter_living_location);
        this.resume_livingLocation_textView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                rItem.setResumeLivingLocation(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        this.resume_biography_textView.setText(this.rItem.getResumeBiography());
        this.resume_biography_textView.setHint(R.string.enter_biography);
        this.resume_biography_textView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                rItem.setResumeBiography(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //this.resume_experience_textView.setText(this.rItem.getResumeExperiences(););
        this.resume_experience_positionTitle.setHint(R.string.enter_extended_experience_title);
        this.resume_experience_employerInformation.setHint(R.string.enter_extended_experience_employer);
        this.resume_experience_jobDuties.setHint(R.string.enter_extended_experience_duties);

        this.resume_education_facility.setHint(R.string.enter_education_facility);
        this.resume_education_degree.setHint(R.string.enter_education_degree);

        this.experienceString = this.rItem.getResumeExperiences();
        this.educationString = this.rItem.getResumeEducations();
        this.experienceArray = new String[60];
        this.educationArray = new String[50];
        this.experienceCount = 0;
        this.educationCount = 0;
        this.experiencePage = 0;
        this.educationPage = 0;


        while (experienceString.contains("_"))
        {
            //Get the first experience.. separated by '_'
            this.indexOf = experienceString.indexOf("_");
            experienceArray[experienceCount] = experienceString.substring(0, this.indexOf);
            if (this.indexOf + 1 == experienceString.length())
            {
                experienceString = "";
            } else {
                experienceString = experienceString.substring(this.indexOf + 1);
            }
            //parse this experience.. separated by '^'
            this.indexOf = experienceArray[experienceCount].indexOf('^');
            while(this.indexOf != -1)
            {
                if(this.indexOf + 1 != experienceArray[experienceCount].length())
                {
                    experienceArray[experienceCount+1] = experienceArray[experienceCount].substring(this.indexOf + 1);
                }
                experienceArray[experienceCount] = experienceArray[experienceCount].substring(0, this.indexOf);
                experienceCount++;
                if(this.experienceArray[experienceCount] != null)
                {
                    this.indexOf = experienceArray[experienceCount].indexOf('^');
                }
                else
                {
                    this.indexOf = -1;
                }
            }
            //set expCount to nearest multiple of 3 to ensure experience indexing is structured as is necessary
            experienceCount -= ((experienceCount%3) - 3)%3;
        }
        if(experienceCount > 2)
        {
            this.resume_experience_positionTitle.setText(experienceArray[0]);
            this.resume_experience_employerInformation.setText(experienceArray[1]);
            this.resume_experience_jobDuties.setText(experienceArray[2]);
        }

        while(educationString.contains("_"))
        {
            educationArray[educationCount] = educationString.substring(0, educationString.indexOf("_"));
            if(educationString.indexOf("_") + 1 == educationString.length()) {
                educationString = "";
            } else {
                educationString = educationString.substring(educationString.indexOf("_") + 1);
            }
            //parse it by '^', add to education count even if ^ dne
            if(educationArray[educationCount].indexOf('^') != -1)
            {
                educationArray[educationCount] = educationArray[educationCount].substring(0, educationArray[educationCount].indexOf('^'));
                educationArray[educationCount + 1] = educationArray[educationCount].substring(educationArray[educationCount].indexOf('^'));
            }
            educationCount += 2;
        }
        if (educationCount > 1)
        {
            this.resume_education_degree.setText(educationArray[0]);
            this.resume_education_facility.setText(educationArray[1]);
        }

        this.resume_experience_menuLeft_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                experienceButtonLeft();
            }
        });
        this.resume_experience_menuRight_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                experienceButtonRight();
            }
        });

        

        this.resume_experience_positionTitle.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateExperiences(0);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        this.resume_experience_employerInformation.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateExperiences(1);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        this.resume_experience_jobDuties.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateExperiences(2);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        this.resume_education_facility.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                rItem.setResumeEducations(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        this.resume_education_degree.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                rItem.setResumeEducations(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        return v;
    }

    private void experienceButtonLeft()
    {
        if (this.experiencePage > 0) {
            this.experiencePage -= 1;
            this.resume_experience_positionTitle.setText(experienceArray[experiencePage * 3] );
            this.resume_experience_employerInformation.setText(experienceArray[(experiencePage*3) + 1]);
            this.resume_experience_jobDuties.setText(experienceArray[(experiencePage*3) + 2]);
        }
        return;
    }

    private void experienceButtonRight()
    {
        if(this.experiencePage < 19)
        {
            Intent intent = getActivity().getIntent();
            if (!intent.getBooleanExtra("flag", false))
            {
                if ((experiencePage + 1) * 3 < experienceCount)
                {
                    this.experiencePage++;
                    this.resume_experience_positionTitle.setText(experienceArray[experiencePage * 3]);
                    this.resume_experience_positionTitle.setHint("");
                    this.resume_experience_employerInformation.setText(experienceArray[(experiencePage * 3) + 1]);
                    this.resume_experience_employerInformation.setHint("");
                    this.resume_experience_jobDuties.setText(experienceArray[(experiencePage * 3) + 2]);
                    this.resume_experience_jobDuties.setHint("");
                }
            }
            else
            {
                this.experiencePage++;
                this.resume_experience_positionTitle.setText(experienceArray[experiencePage * 3]);
                this.resume_experience_employerInformation.setText(experienceArray[(experiencePage * 3) + 1]);
                this.resume_experience_jobDuties.setText(experienceArray[(experiencePage * 3) + 2]);
            }
        }
        if ((experiencePage * 3) >= experienceCount) {
            experienceCount = (experiencePage * 3) + 3;
        }
    }

    private void updateExperiences(int fieldNumber)
    {
        if ((experiencePage * 3) >= experienceCount) {
            experienceCount = (experiencePage * 3) + 3;
        }
        switch(fieldNumber)
        {
            case 0:
                this.experienceArray[experiencePage*3] = this.resume_experience_positionTitle.getText().toString();
                break;
            case 1:
                this.experienceArray[(experiencePage*3)+1] = this.resume_experience_employerInformation.getText().toString();
                break;
            case 2:
                this.experienceArray[(experiencePage*3)+2] = this.resume_experience_jobDuties.getText().toString();
                break;
        }


    }

}
