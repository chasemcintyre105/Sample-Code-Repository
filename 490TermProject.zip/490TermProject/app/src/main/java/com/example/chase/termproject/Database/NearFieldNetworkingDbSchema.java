package com.example.chase.termproject.Database;

public class NearFieldNetworkingDbSchema {

    public static final class CardTable
    {
        public static final String CARDNAME = "cards";

        public static final class CardColumns
        {
            public static final String UUID = "uuid";
            public static final String CARDNAME = "cardname";
            public static final String CARDPHONE = "cardphone";
            public static final String CARDEMAIL = "cardemail";
            public static final String CARDEXPERIENCE = "cardexperience";
            public static final String CARDTAGS = "cardtags";
        }
    }

    public static final class ResumeTable
    {
        public static final String RESUMENAME = "resumes";

        public static final class  ResumeColumns
        {
            public static final String UUID = "uuid";
            public static final String RESUMENAME = "resumename";
            public static final String RESUMECURRENTEMPLOYMENT = "resumecurrentemployment";
            public static final String RESUMELIVINGLOCATION = "resumelivinglocation";
            public static final String RESUMEBIOGRAPHY = "resumebiography";
            public static final String RESUMEEXPERIENCE = "resumeexperience";
            public static final String RESUMEEDUCATION = "resumeeducation";
        }
    }

}
