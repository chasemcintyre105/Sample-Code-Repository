package com.example.chase.termproject;

import android.nfc.NdefRecord;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import java.nio.charset.Charset;
import java.util.Locale;
import java.util.UUID;

import android.app.Activity;
import android.content.Intent;
import android.nfc.NdefMessage;
import android.nfc.NfcAdapter;
import android.nfc.NfcAdapter.CreateNdefMessageCallback;
import android.nfc.NfcEvent;
import android.os.Parcelable;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import static android.nfc.NdefRecord.createMime;

public class tag_sending extends Activity implements CreateNdefMessageCallback  {

    public NfcAdapter mNfcAdapter;
    public TextView textView;
    public Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tag_sending);
        this.textView = (TextView) findViewById(R.id.sendingTextView);
        this.button = (Button) findViewById(R.id.sendingButton);

        mNfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (mNfcAdapter == null) {
            Toast.makeText(this, "NFC is not available", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        // Register callback
        mNfcAdapter.setNdefPushMessageCallback(this, this);
    }

    @Override
    public NdefMessage createNdefMessage(NfcEvent event) {

        UUID myUUID = new UUID(1,1);
        businessCardItem bCard = cardDbConnection.getDbConnection(getBaseContext()).getCard(myUUID);
        resumeItem rItem = resumeDbConnection.getDbConnection(getBaseContext()).getResume(myUUID);

        String cardText = (bCard.getCardName() + "`" + bCard.getCardPhone() + "`" + bCard.getCardEmail() + "`"
                + bCard.getCardExperiences() + "`" + bCard.getCardTags() + "`");
//        cardText.append(bCard.getCardName() + "`" + bCard.getCardPhone() + "`" + bCard.getCardEmail() + "`"
////            + bCard.getCardExperiences() + "`" + bCard.getCardTags() + "`");
        String resumeText = (rItem.getResumeName() + "`" + rItem.getResumeEmployment() + "`" + rItem.getResumeLivingLocation() + "`"
                + rItem.getResumeBiography() + "`" + rItem.getResumeExperiences() + "`" + rItem.getResumeEducations() + "`");

        NdefMessage msg = new NdefMessage(
                new NdefRecord[] { createMime(
                        "application/com.example.chase.termproject", cardText.getBytes())
                        ,NdefRecord.createApplicationRecord("com.example.chase.termproject")
                        ,createMime("application/com.example.chase.termproject", resumeText.getBytes())
                } );

        return msg;
    }

    @Override
    public void onResume() {
        super.onResume();
        // Check to see that the Activity started due to an Android Beam
        if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(getIntent().getAction())) {
            processIntent(getIntent());
        }
    }


    @Override
    public void onNewIntent(Intent intent) {
        // onResume gets called after this to handle the intent
        setIntent(intent);
    }

    /**
     * Parses the NDEF Message from the intent and prints to the TextView
     */
    void processIntent(Intent intent) {
        textView = (TextView) findViewById(R.id.sendingTextView);
        Parcelable[] rawMsgs = intent.getParcelableArrayExtra(
                NfcAdapter.EXTRA_NDEF_MESSAGES);
        // only one message sent during the beam
        NdefMessage msg = (NdefMessage) rawMsgs[0];
        // record 0 contains the MIME type, record 1 is the AAR, if present
        textView.setText(new String(msg.getRecords()[0].getPayload()));
    }
}

//    private NdefRecord createTextRecord(String payload, Locale locale, boolean encodeInUTF8)
//    {
//        byte[] langBytes = locale.getLanguage().getBytes(Charset.forName("US-ASCII"));
//        Charset utfEncoding = encodeInUTF8 ? Charset.forName("UTF-8") : Charset.forName("UTF-16");
//        byte[] textBytes = payload.getBytes(utfEncoding);
//        int utfBit = encodeInUTF8 ? 0 : (1 << 7);
//        char status = (char) (utfBit + langBytes.length);
//        byte[] data = new byte[1 + langBytes.length + textBytes.length];
//        data[0] = (byte) status;
//        System.arraycopy(langBytes,0,data,1,langBytes.length);
//        System.arraycopy(textBytes,0,data,1 + langBytes.length, textBytes.length);
//        NdefRecord record = new NdefRecord(NdefRecord.TNF_WELL_KNOWN,NdefRecord.RTD_TEXT, new byte[0], data);
//        return record;
//    }
