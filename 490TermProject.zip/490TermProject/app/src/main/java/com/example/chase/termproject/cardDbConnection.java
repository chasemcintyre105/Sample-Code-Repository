package com.example.chase.termproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


import com.example.chase.termproject.Database.NearFieldNetworkingDbSchema;
import com.example.chase.termproject.Database.NFNCursorWrapper;
import com.example.chase.termproject.Database.NFNBaseHelper;

public class cardDbConnection {

    private static cardDbConnection thisCardDbConnection;
    private Context context;
    private SQLiteDatabase DB;

    public static cardDbConnection getDbConnection(Context context)
    {
        //if(thisCardDbConnection == null)
        //{
            thisCardDbConnection = new cardDbConnection(context);
        //}
        return thisCardDbConnection;
    }

    private cardDbConnection(Context context)
    {
        this.context = context;
        this.DB = new NFNBaseHelper(this.context).getWritableDatabase();
    }

    public void addCard(businessCardItem bCard)
    {
        ContentValues values = getContentValues(bCard);
        DB.insert(NearFieldNetworkingDbSchema.CardTable.CARDNAME, null, values);
    }

    public void deleteCard(businessCardItem bCard)
    {
        DB.delete(NearFieldNetworkingDbSchema.CardTable.CARDNAME,
                NearFieldNetworkingDbSchema.CardTable.CardColumns.UUID + " = ?", new String[] {bCard.getCardID().toString() }
                );
    }

    public List<businessCardItem> getBusinessCards()
    {
        List<businessCardItem> cards = new ArrayList<businessCardItem>();
        NFNCursorWrapper cursor = queryCrimes(null, null);

        try
        {
            cursor.moveToFirst();
            while(!cursor.isAfterLast())
            {
                cards.add(cursor.getBusinessCard());
                cursor.moveToNext();
            }
        }
        finally
        {
            cursor.close();
        }
        return cards;
    }

    public void updateCard(businessCardItem bCard)
    {
        String UUIDString = bCard.getCardID().toString();
        ContentValues values = getContentValues(bCard);

        DB.update(NearFieldNetworkingDbSchema.CardTable.CARDNAME, values, NearFieldNetworkingDbSchema.CardTable.CardColumns.UUID
            + " = ?", new String[]{UUIDString});
    }

    public businessCardItem getCard(UUID cID)
    {
        NFNCursorWrapper cursor = queryCrimes(NearFieldNetworkingDbSchema.CardTable.CardColumns.UUID + " = ?",
                    new String[]{cID.toString()});
        try
        {
            if(cursor.getCount() == 0)
            {
                return null;
            }
            cursor.moveToFirst();
            return cursor.getBusinessCard();
        }
        finally
        {
            cursor.close();
        }
    }

    private NFNCursorWrapper queryCrimes(String whereClause, String[] whereArgs) {
        Cursor cursor = DB.query(
                NearFieldNetworkingDbSchema.CardTable.CARDNAME,
                null, whereClause, whereArgs,null, null, null);

        return new NFNCursorWrapper(cursor);
    }

    private static ContentValues getContentValues(businessCardItem bCard) {
        ContentValues values = new ContentValues();
        values.put(NearFieldNetworkingDbSchema.CardTable.CardColumns.UUID, bCard.getCardID().toString());
        values.put(NearFieldNetworkingDbSchema.CardTable.CardColumns.CARDNAME, bCard.getCardName());
        values.put(NearFieldNetworkingDbSchema.CardTable.CardColumns.CARDPHONE, bCard.getCardPhone());
        values.put(NearFieldNetworkingDbSchema.CardTable.CardColumns.CARDEMAIL, bCard.getCardEmail());
        values.put(NearFieldNetworkingDbSchema.CardTable.CardColumns.CARDEXPERIENCE, bCard.getCardExperiences());
        values.put(NearFieldNetworkingDbSchema.CardTable.CardColumns.CARDTAGS, bCard.getCardTags());
        return values;
    }


}
