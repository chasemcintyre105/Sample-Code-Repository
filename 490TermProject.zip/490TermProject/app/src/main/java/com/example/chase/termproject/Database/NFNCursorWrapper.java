package com.example.chase.termproject.Database;

import android.database.Cursor;
import android.database.CursorWrapper;

import com.example.chase.termproject.businessCardItem;
import com.example.chase.termproject.resumeItem;

import java.util.UUID;

public class  NFNCursorWrapper extends CursorWrapper {

    public NFNCursorWrapper(Cursor cursor)
    {
        super(cursor);
    }

    public businessCardItem getBusinessCard()
    {
        String uuidString = getString(getColumnIndex(NearFieldNetworkingDbSchema.CardTable.CardColumns.UUID));
        String cardName = getString(getColumnIndex(NearFieldNetworkingDbSchema.CardTable.CardColumns.CARDNAME));
        String cardPhone = getString(getColumnIndex(NearFieldNetworkingDbSchema.CardTable.CardColumns.CARDPHONE));
        String cardEmail = getString(getColumnIndex(NearFieldNetworkingDbSchema.CardTable.CardColumns.CARDEMAIL));
        String cardExperience = getString(getColumnIndex(NearFieldNetworkingDbSchema.CardTable.CardColumns.CARDEXPERIENCE));
        String cardTags = getString(getColumnIndex(NearFieldNetworkingDbSchema.CardTable.CardColumns.CARDTAGS));

        businessCardItem card = new businessCardItem(UUID.fromString(uuidString));
        card.setCardName(cardName);
        card.setCardPhone(cardPhone);
        card.setCardEmail(cardEmail);
        card.setCardExperiences(cardExperience);
        card.setCardTags(cardTags);

        return card;
    }

    public resumeItem getResume()
    {
        String uuidString = getString(getColumnIndex(NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.UUID));
        String resumeName = getString(getColumnIndex(NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.RESUMENAME));
        String resumeEmployment = getString(getColumnIndex(NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.RESUMECURRENTEMPLOYMENT));
        String resumeLivingLocation = getString(getColumnIndex(NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.RESUMELIVINGLOCATION));
        String resumeBiography = getString(getColumnIndex(NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.RESUMEBIOGRAPHY));
        String resumeExperiences = getString(getColumnIndex(NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.RESUMEEXPERIENCE));
        String resumeEducations = getString(getColumnIndex(NearFieldNetworkingDbSchema.ResumeTable.ResumeColumns.RESUMEEDUCATION));

        resumeItem rItem = new resumeItem(UUID.fromString(uuidString));
        rItem.setResumeName(resumeName);
        rItem.setResumeEmployment(resumeEmployment);
        rItem.setResumeLivingLocation(resumeLivingLocation);
        rItem.setResumeBiography(resumeBiography);
        rItem.setResumeExperiences(resumeExperiences);
        rItem.setResumeEducations(resumeEducations);

        return rItem;
    }
}
