package com.example.chase.termproject;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Date;
import java.util.UUID;

public class cardFragment extends Fragment {

    private static final String ARG_CARD_ID = "card_id";
    private static final int REQUEST_DATE = 0;

    private businessCardItem bCard;
    private EditText nameEditText;
    private EditText phoneEditText;
    private EditText emailEditText;
    private EditText experienceView0;
    private EditText experienceView1;
    private EditText tagView0;
    private EditText tagView1;
    private EditText tagView2;
    private EditText tagView3;
    private Button menuLeft;
    private Button menuRight;

    private int i = 0;
    private int j = 0;
    private View experience_view;
    private TextView temp_textview;

    private String experienceString;
    private String experienceArray[];
    private String tagsString;
    private String tagsArray[];
    private StringBuilder experienceStringBuilder;
    private StringBuilder tagStringBuilder;
    private int experienceCount;
    private int tagCount;
    private int tagPage;

    public boolean removeViewFlag = false;

    public static cardFragment newInstance(UUID cID) {
        Bundle args = new Bundle();
        args.putSerializable(ARG_CARD_ID, cID);

        cardFragment fragment = new cardFragment();
        fragment.setArguments(args);
        return fragment;
    }

    public static cardFragment removeViews(cardFragment card_fragment)
    {
        card_fragment.removeViewFlag = true;
//        View card_view = card_fragment.getView();
//        ViewGroup card_viewgroup = (ViewGroup) card_view;
//        card_viewgroup.removeViewAt(card_viewgroup.indexOfChild(card_view.findViewById(R.id.card_view_top)));
//        return card_fragment;
        return card_fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        UUID cID = (UUID) getArguments().getSerializable(ARG_CARD_ID);
        this.bCard = cardDbConnection.getDbConnection(getActivity()).getCard(cID);
    }

    @Override
    public void onPause() {
        super.onPause();
        cardDbConnection.getDbConnection(getActivity()).updateCard(this.bCard);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.delete_card_menu, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.delete_card:
                cardDbConnection.getDbConnection(getActivity()).deleteCard(bCard);
                getActivity().finish();
                break;
            case R.id.email_send:
                StringBuilder emailBody = new StringBuilder();
                if (this.bCard.getCardName().compareTo("") != 0) {
                    emailBody.append(this.bCard.getCardName());
                    emailBody.append('\n');
                }
                if (this.bCard.getCardPhone().compareTo("") != 0) {
                    emailBody.append(this.bCard.getCardPhone());
                    emailBody.append('\n');
                }
                if (this.bCard.getCardEmail().compareTo("") != 0) {
                    emailBody.append(this.bCard.getCardEmail());
                    emailBody.append('\n');
                }
                if (this.bCard.getCardExperiences().compareTo("") != 0) {
                    emailBody.append(this.bCard.getCardExperiences());
                    emailBody.append('\n');
                }
                if (this.bCard.getCardTags().compareTo("") != 0) {
                    emailBody.append(this.bCard.getCardTags());
                    emailBody.append('\n');
                }
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/html");
                intent.putExtra(Intent.EXTRA_TEXT, emailBody.toString());
                startActivity(Intent.createChooser(intent, "Send Email"));
                getActivity().finish();
                break;
            case R.id.sms_send:
                StringBuilder smsBody = new StringBuilder();
                if (this.bCard.getCardName().compareTo("") != 0) {
                    smsBody.append(this.bCard.getCardName());
                    smsBody.append('\n');
                }
                if (this.bCard.getCardPhone().compareTo("") != 0) {
                    smsBody.append(this.bCard.getCardPhone());
                    smsBody.append('\n');
                }
                if (this.bCard.getCardEmail().compareTo("") != 0) {
                    smsBody.append(this.bCard.getCardEmail());
                    smsBody.append('\n');
                }
                if (this.bCard.getCardExperiences().compareTo("") != 0) {
                    smsBody.append(this.bCard.getCardExperiences());
                    smsBody.append('\n');
                }
                if (this.bCard.getCardTags().compareTo("") != 0) {
                    smsBody.append(this.bCard.getCardTags());
                    smsBody.append('\n');
                }
                Intent smsIntent = new Intent(Intent.ACTION_VIEW);
                smsIntent.setData(Uri.parse("sms:"));
                smsIntent.putExtra("sms_body", smsBody.toString());
                startActivity(smsIntent);
                getActivity().finish();
                break;
            default:
                saveTags();
                saveExperiences();
                getActivity().finish();
                return true;
        }
        return false;
    }

    public void saveExperiences() {
        if (this.experienceStringBuilder == null) {
            this.experienceStringBuilder = new StringBuilder();
        }
        //this.experienceStringBuilder.append('`');
        this.bCard.setCardExperiences(this.experienceStringBuilder.toString());
    }

    public void saveTags() {
        this.tagStringBuilder = new StringBuilder();
        for (int i = 0; i <= tagCount; i++) {
            if (tagsArray[i] != null && !tagsArray[i].equals("null") && !tagsArray[i].equals("")) {
                this.tagStringBuilder.append(tagsArray[i]);
                this.tagStringBuilder.append("_");
            }
        }
        //this.tagStringBuilder.append('`');
        Toast.makeText(getContext(), this.tagStringBuilder.toString(), Toast.LENGTH_LONG).show();

        this.bCard.setCardTags(this.tagStringBuilder.toString());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.business_card_view, container, false);

        ViewGroup card_view = (ViewGroup) v;

        if(this.removeViewFlag)
        {
            Toast.makeText(getContext(),"Success8",Toast.LENGTH_LONG).show();
            card_view.removeViewAt(card_view.indexOfChild(v.findViewById(R.id.card_view_top)));
            card_view.removeViewAt(card_view.indexOfChild(v.findViewById(R.id.card_view_bottom)));
        }
        else
        {
            Toast.makeText(getContext(),"Success9",Toast.LENGTH_LONG).show();
        }

        this.nameEditText = (EditText) v.findViewById(R.id.business_card_userName_edittext);
        this.phoneEditText = (EditText) v.findViewById(R.id.business_card_phoneNumber_edittext);
        this.emailEditText = (EditText) v.findViewById(R.id.business_card_emailAddress_edittext);

        this.nameEditText.setText(this.bCard.getCardName());
        this.nameEditText.setHint("Enter Name");
        this.nameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                bCard.setCardName(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        this.phoneEditText.setText(this.bCard.getCardPhone());
        this.phoneEditText.setHint("Enter Phone Number");
        this.phoneEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                bCard.setCardPhone(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        this.emailEditText.setText(bCard.getCardEmail());
        this.emailEditText.setHint("Enter Email");
        this.emailEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                bCard.setCardEmail(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        experience_view = (View) v.findViewById(R.id.business_card_experience_view1);
        ViewGroup parent = (ViewGroup) experience_view.getParent();
        int index = parent.indexOfChild(experience_view);

        //Experiences
        float layoutWeight = (float) .50;
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 60);
        layoutParams.weight = layoutWeight;
        layoutParams.gravity = Gravity.BOTTOM;
        //Experience 1
        temp_textview = new EditText(this.getContext());
        temp_textview.setId(j);
        j++;
        temp_textview.setHint(R.string.add_job_experience);
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);

        //Experience 2
        experience_view = (View) v.findViewById(R.id.business_card_experience_view2);
        parent = (ViewGroup) experience_view.getParent();
        index = parent.indexOfChild(experience_view);
        temp_textview = new EditText(this.getContext());
        temp_textview.setId(j);
        j++;
        temp_textview.setHint(R.string.add_job_experience);
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);


        this.i = 0;
        //Tags
        layoutWeight = (float) 45;
        layoutParams = new LinearLayout.LayoutParams(0, 100);
        layoutParams.weight = layoutWeight;
        layoutParams.gravity = Gravity.BOTTOM;
        layoutParams.topMargin = 0;
        //Tag 1
        experience_view = (View) v.findViewById(R.id.business_card_tag_view1);
        parent = (ViewGroup) experience_view.getParent();
        index = parent.indexOfChild(experience_view);
        temp_textview = new EditText(this.getContext());
        temp_textview.setId(j);
        j++;
        temp_textview.setHint(R.string.enter_skill_tag);
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);
        //Tag 2
        experience_view = (View) v.findViewById(R.id.business_card_tag_view2);
        parent = (ViewGroup) experience_view.getParent();
        index = parent.indexOfChild(experience_view);
        temp_textview = new EditText(this.getContext());
        temp_textview.setId(j);
        j++;
        temp_textview.setHint(R.string.enter_skill_tag);
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);
        //Tag 3
        experience_view = (View) v.findViewById(R.id.business_card_tag_view3);
        parent = (ViewGroup) experience_view.getParent();
        index = parent.indexOfChild(experience_view);
        temp_textview = new EditText(this.getContext());
        temp_textview.setId(j);
        j++;
        temp_textview.setHint(R.string.enter_skill_tag);
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);
        //Tag 4
        experience_view = (View) v.findViewById(R.id.business_card_tag_view4);
        parent = (ViewGroup) experience_view.getParent();
        index = parent.indexOfChild(experience_view);
        temp_textview = new EditText(this.getContext());
        temp_textview.setId(j);
        j++;
        temp_textview.setHint(R.string.enter_skill_tag);
        temp_textview.setGravity(Gravity.BOTTOM);
        temp_textview.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        temp_textview.setLayoutParams(layoutParams);
        temp_textview.setTextSize(12);
        parent.removeViewAt(index);
        parent.addView(temp_textview, index);

        j = 0;
        this.experienceView0 = v.findViewById(j);
        j++;
        this.experienceView1 = v.findViewById(j);
        j++;
        this.tagView0 = v.findViewById(j);
        j++;
        this.tagView1 = v.findViewById(j);
        j++;
        this.tagView2 = v.findViewById(j);
        j++;
        this.tagView3 = v.findViewById(j);
        j++;


        this.experienceString = bCard.getCardExperiences();
        this.experienceArray = new String[100];
        this.tagsString = bCard.getCardTags();
        this.tagsArray = new String[100];
        this.experienceCount = 0;
        this.tagCount = 0;
        this.tagPage = 0;


        if (!experienceString.equals("")) {
            while (experienceString.contains("_")) {
                experienceArray[experienceCount] = experienceString.substring(0, experienceString.indexOf("_"));
                if (experienceString.indexOf("_") + 1 == experienceString.length()) {
                    experienceString = "";
                } else {
                    experienceString = experienceString.substring(experienceString.indexOf("_") + 1);
                }
                experienceCount++;
            }
            if (experienceCount > 0) {
                experienceView0.setText(experienceArray[0]);
            }
            if (experienceCount > 1) {
                experienceView1.setText(experienceArray[1]);
            }
        }

        //tags are separated by the char '_'
        if (!tagsString.equals("")) {
            //Toast.makeText(getContext(), tagsString, Toast.LENGTH_LONG).show();

            while (tagsString.contains("_")) {
                tagsArray[tagCount] = tagsString.substring(0, tagsString.indexOf("_"));
                if (tagsString.indexOf("_") + 1 == tagsString.length()) {
                    tagsString = "";
                } else {
                    tagsString = tagsString.substring(tagsString.indexOf("_") + 1);
                }
                tagCount++;
            }

            if (tagCount > 0) {
                this.tagView0.setText(tagsArray[0]);
            }
            if (tagCount > 1) {
                this.tagView1.setText(tagsArray[1]);
            }
            if (tagCount > 2) {
                this.tagView2.setText(tagsArray[2]);
            }
            if (tagCount > 3) {
                this.tagView3.setText(tagsArray[3]);
            }
        }

        this.experienceView0.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateExperiences();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        this.experienceView1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateExperiences();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        this.tagView0.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateTags(0);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        this.tagView1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateTags(1);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        this.tagView2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateTags(2);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        this.tagView3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateTags(3);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        Intent intent = getActivity().getIntent();
        UUID testUUID = new UUID(1, 1);
        if (!intent.getBooleanExtra("flag", false)) {
            if (!this.bCard.getCardID().equals(testUUID)) {
                this.emailEditText.setInputType(0);
                this.phoneEditText.setInputType(0);
                this.nameEditText.setInputType(0);
                this.experienceView0.setInputType(0);
                this.experienceView1.setInputType(0);
                this.tagView0.setInputType(0);
                this.tagView1.setInputType(0);
                this.tagView2.setInputType(0);
                this.tagView3.setInputType(0);
            }
        }


        this.menuLeft = v.findViewById(R.id.business_card_menuLeft_button);
        this.menuRight = v.findViewById(R.id.business_card_menuRight_button);

        this.menuLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menuLeftButton();
            }
        });
        this.menuRight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menuRightButton();
            }
        });

        return v;
    }

    public void menuLeftButton() {
        if (this.tagPage > 0) {
            tagPage--;
            this.tagView0.setText(tagsArray[tagPage * 4]);
            this.tagView1.setText(tagsArray[(tagPage * 4) + 1]);
            this.tagView2.setText(tagsArray[(tagPage * 4) + 2]);
            this.tagView3.setText(tagsArray[(tagPage * 4) + 3]);
        }
        return;
    }

    public void menuRightButton() {
        if (tagPage <= 24) {
            Intent intent = getActivity().getIntent();
            if (!intent.getBooleanExtra("flag", false)) {
                if (!((tagPage + 1) * 4 >= tagCount)) {
                    tagPage++;
                    this.tagView0.setText(tagsArray[tagPage * 4]);
                    this.tagView0.setHint("");
                    this.tagView1.setText(tagsArray[(tagPage * 4) + 1]);
                    this.tagView1.setHint("");
                    this.tagView2.setText(tagsArray[(tagPage * 4) + 2]);
                    this.tagView2.setHint("");
                    this.tagView3.setText(tagsArray[(tagPage * 4) + 3]);
                    this.tagView3.setHint("");
                }
            } else {
                tagPage++;
                this.tagView0.setText(tagsArray[tagPage * 4]);
                this.tagView1.setText(tagsArray[(tagPage * 4) + 1]);
                this.tagView2.setText(tagsArray[(tagPage * 4) + 2]);
                this.tagView3.setText(tagsArray[(tagPage * 4) + 3]);
            }
            //not last page, perform action
        }
        if ((tagPage * 4) + 3 > tagCount) {
            tagCount = (tagPage * 4) + 3;
        }
    }

    public void updateTags(int tagView) {
        if ((tagPage * 4) + 3 > tagCount) {
            tagCount = (tagPage * 4) + 3;
        }
        switch (tagView) {
            case 0:
                tagsArray[tagPage * 4] = tagView0.getText().toString();
                break;
            case 1:
                tagsArray[(tagPage * 4) + 1] = tagView1.getText().toString();
                break;
            case 2:
                tagsArray[(tagPage * 4) + 2] = tagView2.getText().toString();
                break;
            case 3:
                tagsArray[(tagPage * 4) + 3] = tagView3.getText().toString();
                break;
        }
    }

    public void updateExperiences() {
        this.experienceStringBuilder = new StringBuilder();
        if (experienceView0.getText().toString().compareTo("") != 0) {
            this.experienceStringBuilder.append(this.experienceView0.getText().toString());
            this.experienceStringBuilder.append("_");
        }
        if (experienceView1.getText().toString().compareTo("") != 0) {
            this.experienceStringBuilder.append(this.experienceView1.getText().toString());
            this.experienceStringBuilder.append("_");
        }
        this.experienceStringBuilder.append('`');
    }
}